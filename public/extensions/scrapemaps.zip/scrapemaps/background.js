/**
 * ScrapeMaps - Background Service Worker
 * Orchestrates the scraping loop even after popup closure
 */

let scrapingState = {
  active: false,
  tabId: null,
  limit: 20,
  current: 0,
  stopRequested: false
};

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "startScrape") {
    startScraping(request.tabId, request.limit);
    sendResponse({ status: "started" });
  } else if (request.action === "stopScrape") {
    scrapingState.stopRequested = true;
    sendResponse({ status: "stopping" });
  } else if (request.action === "getState") {
    sendResponse(scrapingState);
  }
  return true;
});

async function startScraping(tabId, limit) {
  if (scrapingState.active) return;

  scrapingState = {
    active: true,
    tabId: tabId,
    limit: limit,
    current: 0,
    stopRequested: false
  };

  updateStorageState();

  try {
    // Step 1: Perform Auto-scroll to load search items
    await autoScrollInTab(tabId, limit);

    if (scrapingState.stopRequested) throw new Error("Stopped");

    // Step 2: Get total loaded items in the list
    const totalLoaded = await executeInTab(tabId, getItemCountInPage);
    const toProcess = Math.min(limit, totalLoaded || 0);

    // Load initial scraped data list to skip duplicates
    const stored = await chrome.storage.local.get(['scrapedData']);
    let allScraped = stored.scrapedData || [];
    const seenKeys = new Set(allScraped.map(d => `${d.name}|${d.address}`));

    // Step 3: Loop through each item in the detail pane
    for (let i = 0; i < toProcess; i++) {
        if (scrapingState.stopRequested) break;

        scrapingState.current = i + 1;
        updateStorageState();

        // Click item at index i
        await executeInTab(tabId, clickListItemInPage, [i]);
        await sleep(2500); // detail panel load time

        // Scrape detail
        const detail = await executeInTab(tabId, scrapeDetailInPage);
        
        if (detail && detail.name) {
            const key = `${detail.name}|${detail.address}`;
            if (!seenKeys.has(key)) {
                allScraped.push(detail);
                seenKeys.add(key);
                // Save incrementally so progress is never lost
                await chrome.storage.local.set({ scrapedData: allScraped });
            }
        }

        // Return to search results list
        await executeInTab(tabId, clickBackButtonInPage);
        await sleep(1500);
    }

  } catch (err) {
    console.error("Background scrape error:", err);
  } finally {
    scrapingState.active = false;
    updateStorageState();
    // Optional: Notify UI with badge or internal message
  }
}

async function autoScrollInTab(tabId, limit) {
    let previousCount = 0;
    let staleTries = 0;

    while (!scrapingState.stopRequested) {
        const scrollInfo = await executeInTab(tabId, doScrollStepInPage);
        if (!scrollInfo) break;

        const count = scrollInfo.itemCount || 0;
        if (count >= limit || scrollInfo.reachedEnd) break;

        if (count === previousCount) {
           if (++staleTries >= 5) break;
        } else {
           staleTries = 0;
        }
        previousCount = count;
        await sleep(1500);
    }
}

function updateStorageState() {
  chrome.storage.local.set({ scrapingState });
}

async function executeInTab(tabId, func, args = []) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: func,
      args: args
    });
    return results?.[0]?.result;
  } catch (e) { return null; }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// --- REUSED INPAGE FUNCTIONS (same logic as before) ---
function doScrollStepInPage() {
  const feed = document.querySelector('[role="feed"]');
  if (!feed) return null;
  const scrollable = feed.closest('.m6QErb[aria-label]') || feed.closest('.m6QErb') || feed.parentElement;
  if (scrollable) scrollable.scrollTop = scrollable.scrollHeight;
  const items = document.querySelectorAll('[role="feed"] > div > div > a[href*="/maps/place/"]');
  const endIndicators = document.querySelectorAll('.m6QErb .HlvSq, .m6QErb p span');
  let reachedEnd = Array.from(endIndicators).some(el => {
    const t = el.textContent.toLowerCase();
    return t.includes('end of') || t.includes('tidak ada lagi') || t.includes("reached");
  });
  return { itemCount: items.length, reachedEnd };
}

function getItemCountInPage() {
  return document.querySelectorAll('[role="feed"] > div > div > a[href*="/maps/place/"]').length;
}

function clickListItemInPage(idx) {
  const items = document.querySelectorAll('[role="feed"] > div > div > a[href*="/maps/place/"]');
  if (items[idx]) { items[idx].click(); return true; }
  return false;
}

function clickBackButtonInPage() {
  const backBtn = document.querySelector('button[aria-label="Back"], button[aria-label="Kembali"]');
  if (backBtn) { backBtn.click(); return true; }
  const allBtns = document.querySelectorAll('button[jsaction]');
  for (const btn of allBtns) {
    const label = (btn.getAttribute('aria-label') || '').toLowerCase();
    if (label.includes('back') || label.includes('kembali')) { btn.click(); return true; }
  }
  window.history.back(); return true;
}

function scrapeDetailInPage() {
  const d = { name: '', address: '', phone: '', rating: '', reviewCount: '', website: '', category: '', url: window.location.href };
  const titleEl = document.querySelector('h1.DUwDvf, .DUwDvf, h1.fontHeadlineLarge');
  if (titleEl) {
      d.name = titleEl.textContent.trim();
      if (d.name.toLowerCase().includes('hasil') || d.name.toLowerCase().includes('results')) {
          const alt = document.querySelector('.DUwDvf');
          if (alt) d.name = alt.textContent.trim();
      }
  }
  if (!d.name) {
    const h1s = Array.from(document.querySelectorAll('h1'));
    for (const h of h1s) {
      if (!h.textContent.includes('Hasil') && !h.textContent.includes('Results')) { d.name = h.textContent.trim(); break; }
    }
  }

  const rEl = document.querySelector('div.F7nice span[aria-hidden="true"]');
  if (rEl) { const m = rEl.textContent.match(/([\d.,]+)/); if (m) d.rating = m[1].replace(',', '.'); }
  const revEl = document.querySelector('div.F7nice span[aria-label]');
  if (revEl) { const m = revEl.getAttribute('aria-label').match(/([\d.,]+)/); if (m) d.reviewCount = m[1].replace('.', '').replace(',', ''); }
  const catEl = document.querySelector('button[jsaction*="category"], .DkEaL');
  if (catEl) d.category = catEl.textContent.trim();

  document.querySelectorAll('[data-item-id]').forEach(item => {
    const id = item.getAttribute('data-item-id') || '';
    const label = item.getAttribute('aria-label') || '';
    const text = item.textContent.trim();
    if (id.startsWith('address')) {
      const addr = label.replace(/^Alamat:\s*/i, '').replace(/^Address:\s*/i, '') || text;
      if (addr && addr.length > 3 && !/^[A-Z0-9]{4,8}\+[A-Z0-9]{2,}/i.test(addr)) d.address = addr;
    }
    if (id.startsWith('phone')) {
      const p = label.replace(/^Telepon:\s*/i, '').replace(/^Phone:\s*/i, '') || text;
      if (p && /\d/.test(p)) d.phone = p;
    }
    if (id === 'authority') {
      const a = item.querySelector('a') || item;
      d.website = a.href || a.textContent.trim();
    }
  });
  return d.name ? d : null;
}
