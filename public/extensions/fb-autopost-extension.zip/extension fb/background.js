// Background script for Facebook Auto Poster Extension

let isPosting = false;
let currentGroupIndex = 0;
let postingData = null;

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "startBot") {
    startAutoPosting(request.data);
  }
});

async function checkQuota() {
  return true;
}

// Start auto posting process
// Start auto posting process
async function startAutoPosting(data) {
  if (isPosting) {
    console.log("Bot already running");
    return;
  }

  isPosting = true;
  currentGroupIndex = 0;
  postingData = data;

  try {
    // Check if we have Facebook tab open
    const tabs = await chrome.tabs.query({ url: "*://*.facebook.com/*" });
    let facebookTab;

    if (tabs.length === 0) {
      // Create new Facebook tab
      facebookTab = await chrome.tabs.create({
        url: "https://www.facebook.com/",
        active: true,
      });

      // Wait for tab to load
      await waitForTabLoad(facebookTab.id);
    } else {
      // Gunakan tab Facebook yang sudah ada
      facebookTab = tabs[0];
      await chrome.tabs.update(facebookTab.id, { active: true });

      // Pastikan tab sudah dimuat
      await waitForTabLoad(facebookTab.id);
    }

    // Start posting to groups
    await postToGroups(facebookTab.id);
  } catch (error) {
    console.error("Auto posting failed:", error);
    isPosting = false;
  }
}
async function updateUsedGroup(groupUrl) {
  // Api limit removed
}

function sendProgress(status, data = {}) {
  chrome.runtime.sendMessage({
    action: "progressUpdate",
    status,
    data,
  });
}

function randomDelay(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
// Post to all selected groups
// Post to all selected groups
// Post to all selected groups
async function postToGroups(tabId) {
  const { selectedGroups, postMessage, photos } = postingData;
  let successCount = 0;

  for (let i = 0; i < selectedGroups.length; i++) {
    if (!isPosting) break;

    // Cek kuota
    const masihAdaKuota = await checkQuota();
    if (!masihAdaKuota) {
      sendProgress("limitReached", {
        used: i,
        limit: selectedGroups.length,
        success: successCount,
      });
      break;
    }

    currentGroupIndex = i;
    const groupUrl = selectedGroups[i];

    try {
      sendProgress("posting", {
        index: i + 1,
        total: selectedGroups.length,
        groupUrl,
      });

      // Navigasi ke URL grup di tab yang sama
      await chrome.tabs.update(tabId, { url: groupUrl });
      await waitForTabLoad(tabId);
      await delay(randomDelay(1500, 3000));

      // Eksekusi script posting
      await chrome.scripting.executeScript({
        target: { tabId },
        function: postToGroup,
        args: [postMessage, photos],
      });

      successCount++;
      sendProgress("success", {
        index: i + 1,
        total: selectedGroups.length,
        groupUrl,
        success: successCount,
      });

      await updateUsedGroup(groupUrl);
      await delay(randomDelay(3000, 5000));
    } catch (error) {
      sendProgress("error", { index: i + 1, groupUrl, error: error.message });
      await delay(randomDelay(6000, 8000));
    }
  }

  isPosting = false;
  sendProgress("done", { total: successCount });
}
// Function to be injected into Facebook page for posting
async function postToGroup(postMessage, photos) {
  // Helper function for delays
  const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  // Use the injected FacebookAutoPoster if available
  if (window.FacebookAutoPoster) {
    return await window.FacebookAutoPoster.postToCurrentGroup(
      postMessage,
      photos
    );
  }

  // Fallback method if injected script not available
  try {
    // Find and click "Write something..." button
    let openPostButton = null;
    const spans = Array.from(
      document.querySelectorAll('div[role="button"] span')
    );

    for (const span of spans) {
      const text = span.innerText || span.textContent;
      if (
        text &&
        (text.includes("Tulis sesuatu") || text.includes("Write something"))
      ) {
        openPostButton = span;
        break;
      }
    }

    if (!openPostButton) {
      throw new Error("Post button not found");
    }

    // Click the post button
    openPostButton.click();
    await delay(2000);

    // Wait for modal to appear and find textbox
    let attempts = 0;
    let textbox = null;

    while (attempts < 10 && !textbox) {
      textbox = document.querySelector(
        'div[role="dialog"] div[contenteditable="true"][role="textbox"]'
      );
      if (!textbox) {
        await delay(500);
        attempts++;
      }
    }

    if (!textbox) {
      throw new Error("Text box not found");
    }

    // Focus and insert text
    // Focus textbox
    textbox.focus();
    await delay(500);

    // Cara yang lebih “natural” untuk isi teks
    textbox.innerHTML = "";
    textbox.focus();
    textbox.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: postMessage,
      })
    );

    await delay(1000);

    // Handle photo uploads if any
    if (photos && photos.length > 0) {
      console.log(`Uploading ${photos.length} photos...`);

      try {
        // Find photo/media button
        const mediaButtons = Array.from(
          document.querySelectorAll(
            'div[role="dialog"] div[aria-label*="Foto"], div[role="dialog"] div[aria-label*="Photo"]'
          )
        );

        if (mediaButtons.length > 0) {
          mediaButtons[0].click();
          await delay(1000);

          // Find file input
          const fileInput = document.querySelector(
            'div[role="dialog"] input[type="file"]'
          );

          if (fileInput) {
            // Convert base64 photos to File objects
            const files = [];
            for (const photo of photos) {
              try {
                const response = await fetch(photo.data);
                const blob = await response.blob();
                const file = new File([blob], photo.name, { type: photo.type });
                files.push(file);
              } catch (e) {
                console.error("Failed to convert photo:", e);
              }
            }

            if (files.length > 0) {
              // Create DataTransfer object to simulate file selection
              const dataTransfer = new DataTransfer();
              files.forEach((file) => dataTransfer.items.add(file));

              // Set files to input
              fileInput.files = dataTransfer.files;

              // Trigger change event
              const changeEvent = new Event("change", { bubbles: true });
              fileInput.dispatchEvent(changeEvent);

              // Wait for photos to process
              const processingTime = 3000 + files.length * 2000;
              await delay(processingTime);
            }
          }
        }
      } catch (photoError) {
        console.log(
          "Photo upload failed, continuing without photos:",
          photoError
        );
      }
    }

    // Find and click Post button
    await delay(1000);

    const postButtons = Array.from(
      document.querySelectorAll('div[role="dialog"] div[role="button"] span')
    );
    let postButton = null;

    for (const span of postButtons) {
      const text = span.innerText || span.textContent;
      if (text && (text.trim() === "Posting" || text.trim() === "Post")) {
        postButton = span;
        break;
      }
    }

    if (postButton) {
      postButton.click();
      console.log("Post submitted successfully");
      return true;
    } else {
      throw new Error("Post button not found");
    }
  } catch (error) {
    console.error("Failed to post:", error);
    throw error;
  }
}

// Wait for tab to finish loading
function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    function checkTab() {
      chrome.tabs.get(tabId, (tab) => {
        if (tab && tab.status === "complete") {
          resolve();
        } else {
          setTimeout(checkTab, 100);
        }
      });
    }
    checkTab();
  });
}

// Simple delay function
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
