// Content script for Facebook Auto Poster Extension
// This script runs on Facebook pages to help with automation

(function () {
  "use strict";

  // Check if we're on Facebook
  if (!window.location.href.includes("facebook.com")) {
    return;
  }

  // Inject helper script for better DOM access
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("injected.js");
  script.onload = function () {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);

  if (!window.hasRunAutoPosterListener) {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      if (request.action === "checkLogin") {
        const isLoggedIn =
          !document.querySelector('a[href*="login"]') &&
          document.querySelector(
            '[data-testid="react-composer-post-button"], div[role="button"] span'
          );
        sendResponse({ loggedIn: isLoggedIn });
      }

      if (request.action === "getCurrentGroups") {
        const groups = extractGroupsFromPage();
        sendResponse({ groups });
      }
    });

    window.hasRunAutoPosterListener = true; // ✅ mencegah double listener
  }

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkLogin") {
      // Check if user is logged in to Facebook
      const isLoggedIn =
        !document.querySelector('a[href*="login"]') &&
        document.querySelector(
          '[data-testid="react-composer-post-button"], div[role="button"] span'
        );
      sendResponse({ loggedIn: isLoggedIn });
    }

    if (request.action === "getCurrentGroups") {
      // Get groups from current page
      const groups = extractGroupsFromPage();
      sendResponse({ groups });
    }
  });

  // Function to extract group URLs from current page
  function extractGroupsFromPage() {
    const links = Array.from(document.querySelectorAll('a[href*="/groups/"]'));
    const groupUrls = links
      .map((a) => a.href)
      .filter((href) =>
        /^https:\/\/www\.facebook\.com\/groups\/[^\/]+\/?$/.test(href)
      )
      .filter((url, index, self) => self.indexOf(url) === index); // Remove duplicates

    return groupUrls;
  }

  // Auto-scroll function for loading more content
  window.autoScroll = function (maxScrolls = 10) {
    return new Promise((resolve) => {
      let scrollCount = 0;
      let lastHeight = document.body.scrollHeight;

      function scroll() {
        if (scrollCount >= maxScrolls) {
          resolve();
          return;
        }

        window.scrollTo(0, document.body.scrollHeight);
        scrollCount++;

        setTimeout(() => {
          const newHeight = document.body.scrollHeight;
          if (newHeight === lastHeight) {
            resolve(); // No more content to load
          } else {
            lastHeight = newHeight;
            scroll();
          }
        }, 2000);
      }

      scroll();
    });
  };

  // Helper function to wait for element
  window.waitForElement = function (selector, timeout = 10000) {
    return new Promise((resolve, reject) => {
      const element = document.querySelector(selector);
      if (element) {
        resolve(element);
        return;
      }

      const observer = new MutationObserver((mutations, obs) => {
        const element = document.querySelector(selector);
        if (element) {
          obs.disconnect();
          resolve(element);
        }
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true,
      });

      setTimeout(() => {
        observer.disconnect();
        reject(new Error(`Element ${selector} not found within ${timeout}ms`));
      }, timeout);
    });
  };

  // Helper function to simulate human-like delays
  window.humanDelay = function (min = 1000, max = 3000) {
    const delay = Math.floor(Math.random() * (max - min + 1)) + min;
    return new Promise((resolve) => setTimeout(resolve, delay));
  };

  // Enhanced click function that simulates human behavior
  window.humanClick = async function (element) {
    if (!element) return false;

    // Scroll element into view
    element.scrollIntoView({ behavior: "smooth", block: "center" });
    await window.humanDelay(500, 1000);

    // Simulate mouse events
    const events = ["mouseover", "mousedown", "mouseup", "click"];
    events.forEach((eventType) => {
      const event = new MouseEvent(eventType, {
        bubbles: true,
        cancelable: true,
        view: window,
      });
      element.dispatchEvent(event);
    });

    return true;
  };

  // Function to safely paste text
  window.safeTextInsert = async function (textbox, text) {
    if (!textbox) return false;

    textbox.focus();
    await window.humanDelay(200, 500);

    try {
      // Method 1: Use clipboard API if available
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);

        // Simulate Ctrl+V
        textbox.dispatchEvent(
          new KeyboardEvent("keydown", {
            key: "v",
            ctrlKey: true,
            bubbles: true,
          })
        );

        await window.humanDelay(500, 1000);
        return true;
      }

      // Method 2: Direct insertion
      textbox.innerHTML = "";
      textbox.innerText = text;

      // Trigger events
      textbox.dispatchEvent(new Event("input", { bubbles: true }));
      textbox.dispatchEvent(new Event("change", { bubbles: true }));

      return true;
    } catch (error) {
      console.error("Failed to insert text:", error);
      return false;
    }
  };

  console.log("Facebook Auto Poster content script loaded");
})();
