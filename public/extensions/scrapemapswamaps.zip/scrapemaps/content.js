/**
 * ScrapeMaps - Content Script
 * Injected into Google Maps pages
 * Handles auto-scroll and enhanced scraping
 */

// Listen for messages from popup or background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ping') {
    sendResponse({ status: 'ok' });
    return true;
  }

  if (message.action === 'autoScroll') {
    autoScrollAndScrape(message.maxResults || 100)
      .then(data => sendResponse({ data }))
      .catch(err => sendResponse({ error: err.message }));
    return true; // async response
  }
});

/**
 * Auto-scroll the results panel to load more businesses
 */
async function autoScrollAndScrape(maxResults) {
  const feed = document.querySelector('[role="feed"]');
  if (!feed) {
    throw new Error('Tidak menemukan panel hasil pencarian.');
  }

  const scrollContainer = feed.closest('.m6QErb[aria-label*="Results"], .m6QErb[aria-label*="Hasil"], .m6QErb') || feed.parentElement;

  if (!scrollContainer) {
    throw new Error('Tidak menemukan container scroll.');
  }

  let previousCount = 0;
  let sameCountTries = 0;

  while (sameCountTries < 5) {
    // Scroll down
    scrollContainer.scrollTop = scrollContainer.scrollHeight;
    await new Promise(r => setTimeout(r, 2000));

    const currentItems = document.querySelectorAll('a[href*="/maps/place/"]');
    const currentCount = currentItems.length;

    if (currentCount >= maxResults) break;

    if (currentCount === previousCount) {
      sameCountTries++;
    } else {
      sameCountTries = 0;
    }
    previousCount = currentCount;

    // Check if end of results
    const endMsg = document.querySelector('.m6QErb .HlvSq, .m6QErb p span, .Pb9p9c');
    if (endMsg) {
        const t = endMsg.textContent.toLowerCase();
        if (t.includes('end of') || t.includes('tidak ada lagi') || t.includes("reached") || t.includes("akhir")) break;
    }
  }

  return true;
}
