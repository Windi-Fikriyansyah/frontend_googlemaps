// Injected script for Facebook Auto Poster Extension
// This script runs in the page context for better DOM access

(function () {
  "use strict";

  // Enhanced Facebook posting functions
  window.FacebookAutoPoster = {
    // Main function to post to a group
    async postToCurrentGroup(postMessage, photos = []) {
      try {
        console.log("Starting post process...");

        // Step 1: Find and click post button
        const postButtonClicked = await this.clickPostButton();
        if (!postButtonClicked) {
          throw new Error("Could not find or click post button");
        }

        // Step 2: Wait for modal and insert text
        const textInserted = await this.insertPostText(postMessage);
        if (!textInserted) {
          throw new Error("Could not insert post text");
        }

        // Step 3: Upload photos if any
        if (photos && photos.length > 0) {
          const photosUploaded = await this.uploadPhotos(photos);
          if (!photosUploaded) {
            console.warn("Photo upload failed, continuing without photos");
          }
        }

        // Step 4: Submit post
        const postSubmitted = await this.submitPost();
        if (!postSubmitted) {
          throw new Error("Could not submit post");
        }

        console.log("Post completed successfully");
        return true;
      } catch (error) {
        console.error("Post failed:", error);

        // Try to close modal if open
        this.closeModal();
        return false;
      }
    },

    // Find and click the "Write something..." button
    async clickPostButton() {
      const selectors = [
        'div[role="button"] span',
        '[data-testid="status-attachment-mentions-input"]',
        'div[data-testid="react-composer-post-button"]',
        'div[aria-label*="Write"]',
        'div[aria-label*="Tulis"]',
      ];

      for (const selector of selectors) {
        const elements = document.querySelectorAll(selector);

        for (const element of elements) {
          const text = element.innerText || element.textContent || "";

          if (
            text.includes("Tulis sesuatu") ||
            text.includes("Write something") ||
            text.includes("What's on your mind") ||
            text.includes("Apa yang Anda pikirkan")
          ) {
            await this.humanClick(element);
            await this.delay(2000, 3000);
            return true;
          }
        }
      }

      return false;
    },

    // Insert text into the post modal
    async insertPostText(postMessage) {
      const textboxSelectors = [
        'div[role="dialog"] div[contenteditable="true"][role="textbox"]',
        'div[role="dialog"] div[contenteditable="true"]',
        'div[data-testid="react-composer-post-input"]',
        'div[aria-label*="What\'s on your mind"]',
        'div[aria-label*="Apa yang Anda pikirkan"]',
      ];

      let textbox = null;
      let attempts = 0;

      // Wait for textbox to appear
      while (attempts < 20 && !textbox) {
        for (const selector of textboxSelectors) {
          textbox = document.querySelector(selector);
          if (textbox) break;
        }

        if (!textbox) {
          await this.delay(500);
          attempts++;
        }
      }

      if (!textbox) {
        return false;
      }

      // Focus and clear textbox
      textbox.focus();
      await this.delay(500);

      // Insert text using multiple methods
      try {
        // Method 1: Clipboard API
        if (navigator.clipboard && window.isSecureContext) {
          await navigator.clipboard.writeText(postMessage);

          const ctrlV = new KeyboardEvent("keydown", {
            key: "v",
            ctrlKey: true,
            bubbles: true,
            cancelable: true,
          });
          textbox.dispatchEvent(ctrlV);

          await this.delay(1000);

          // Check if text was inserted
          if (textbox.innerText.includes(postMessage)) {
            return true;
          }
        }

        // Method 2: Direct insertion
        textbox.innerHTML = "";
        textbox.innerText = postMessage;

        // Trigger events
        const events = ["input", "change", "keyup"];
        events.forEach((eventType) => {
          const event = new Event(eventType, { bubbles: true });
          textbox.dispatchEvent(event);
        });

        await this.delay(500);
        return true;
      } catch (error) {
        console.error("Text insertion failed:", error);
        return false;
      }
    },

    // Upload photos to the post
    async uploadPhotos(photos) {
      try {
        // Find photo/media button
        const mediaButtonSelectors = [
          'div[role="dialog"] div[aria-label*="Foto"]',
          'div[role="dialog"] div[aria-label*="Photo"]',
          'div[role="dialog"] svg[aria-label*="Photo"]',
          'div[role="dialog"] div[data-testid*="photo"]',
        ];

        let mediaButton = null;
        for (const selector of mediaButtonSelectors) {
          mediaButton = document.querySelector(selector);
          if (mediaButton) break;
        }

        if (!mediaButton) {
          console.warn("Media button not found");
          return false;
        }

        // Click media button
        await this.humanClick(mediaButton);
        await this.delay(1000, 2000);

        // Find file input
        const fileInput =
          document.querySelector('div[role="dialog"] input[type="file"]') ||
          document.querySelector('input[accept*="image"]') ||
          document.querySelector('input[type="file"]');

        if (!fileInput) {
          console.warn("File input not found");
          return false;
        }

        // Convert base64 photos to File objects
        const files = [];
        for (const photo of photos) {
          try {
            const response = await fetch(photo.data);
            const blob = await response.blob();
            const file = new File([blob], photo.name, { type: photo.type });
            files.push(file);
          } catch (e) {
            console.error("Failed to convert photo:", e);
          }
        }

        if (files.length === 0) {
          return false;
        }

        // Create DataTransfer object
        const dataTransfer = new DataTransfer();
        files.forEach((file) => dataTransfer.items.add(file));

        // Set files to input
        fileInput.files = dataTransfer.files;

        // Trigger change event
        const changeEvent = new Event("change", { bubbles: true });
        fileInput.dispatchEvent(changeEvent);

        // Wait for photos to process
        const processingTime = 3000 + files.length * 2000;
        await this.delay(processingTime);

        console.log(`Successfully uploaded ${files.length} photos`);
        return true;
      } catch (error) {
        console.error("Photo upload failed:", error);
        return false;
      }
    },

    // Submit the post
    async submitPost() {
      const postButtonSelectors = [
        'div[role="dialog"] div[role="button"] span',
        'div[role="dialog"] button span',
        'div[data-testid="react-composer-post-button"]',
      ];

      let postButton = null;

      // Find post button
      for (const selector of postButtonSelectors) {
        const elements = document.querySelectorAll(selector);

        for (const element of elements) {
          const text = element.innerText || element.textContent || "";

          if (
            text.trim() === "Posting" ||
            text.trim() === "Post" ||
            text.trim() === "Bagikan" ||
            text.trim() === "Share"
          ) {
            postButton = element;
            break;
          }
        }

        if (postButton) break;
      }

      if (!postButton) {
        console.error("Post button not found");
        return false;
      }

      // Click post button
      await this.humanClick(postButton);
      await this.delay(2000, 3000);

      return true;
    },

    // Close modal if something goes wrong
    closeModal() {
      try {
        const closeButtons = document.querySelectorAll(
          'div[role="dialog"] div[role="button"][aria-label*="Close"], div[role="dialog"] div[role="button"][aria-label*="Tutup"]'
        );

        if (closeButtons.length > 0) {
          closeButtons[0].click();
        }
      } catch (error) {
        console.error("Failed to close modal:", error);
      }
    },

    // Human-like click simulation
    async humanClick(element) {
      if (!element) return false;

      // Scroll into view
      element.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "center",
      });

      await this.delay(500, 1000);

      // Simulate mouse events
      const rect = element.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;

      const events = [
        new MouseEvent("mouseover", {
          bubbles: true,
          cancelable: true,
          clientX: x,
          clientY: y,
        }),
        new MouseEvent("mousedown", {
          bubbles: true,
          cancelable: true,
          clientX: x,
          clientY: y,
        }),
        new MouseEvent("mouseup", {
          bubbles: true,
          cancelable: true,
          clientX: x,
          clientY: y,
        }),
        new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          clientX: x,
          clientY: y,
        }),
      ];

      events.forEach((event) => {
        element.dispatchEvent(event);
      });

      return true;
    },

    // Random delay function
    delay(min = 1000, max = 3000) {
      const delay = Math.floor(Math.random() * (max - min + 1)) + min;
      return new Promise((resolve) => setTimeout(resolve, delay));
    },

    // Check if user is logged in
    isLoggedIn() {
      return (
        !document.querySelector('a[href*="login"]') &&
        (document.querySelector('[data-testid="react-composer-post-button"]') ||
          document.querySelector('div[role="button"] span') ||
          document.querySelector('div[contenteditable="true"]'))
      );
    },

    // Get current page groups
    extractGroups() {
      const links = Array.from(
        document.querySelectorAll('a[href*="/groups/"]')
      );
      return links
        .map((a) => a.href)
        .filter((href) =>
          /^https:\/\/www\.facebook\.com\/groups\/[^\/]+\/?(\?.*)?$/.test(href)
        )
        .map((href) => href.split("?")[0]) // Remove query parameters
        .filter((url, index, self) => self.indexOf(url) === index); // Remove duplicates
    },
  };

  console.log("Facebook Auto Poster injected script loaded");
})();
