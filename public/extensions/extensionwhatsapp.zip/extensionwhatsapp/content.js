/* content.js - WhatsApp Business Web Sender (Unsaved Numbers Support) */
console.log('[WA] Content script loaded ✓');

let msgCount = 0;
let isProcessing = false;
let processTimeout = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'sendMessage') {
        console.log('[WA] → New message request for:', request.phone);
        
        if (isProcessing) {
            console.warn('[WA] ⚠ Busy processing. Skipping request.');
            sendResponse({ status: 'busy' });
        } else {
            // Safety: ensure we don't stay locked forever (max 60s)
            clearTimeout(processTimeout);
            processTimeout = setTimeout(() => {
                if (isProcessing) {
                    console.error('[WA] ⚠ Processing took too long (60s). Re-enabling for next turn.');
                    isProcessing = false;
                }
            }, 60000);

            handleSendMessage(request);
            sendResponse({ received: true });
        }
    }
    if (request.action === 'ping') {
        sendResponse({ alive: true, processing: isProcessing });
    }
    return true;
});

// ══════════════════════════════════════════════════════════════
//  MAIN FLOW
// ══════════════════════════════════════════════════════════════
async function handleSendMessage(request) {
    const { phone, message, typingSim } = request;

    try {
        isProcessing = true;
        msgCount++;

        // Anti-ban periodic break (every 8 messages)
        if (msgCount > 1 && msgCount % 8 === 0) {
            console.log('[WA] Anti-ban break (local)...');
            await sleep(randomBetween(3000, 5000));
        }

        // ── 1. Reset to main screen ──────────────────────────
        console.log('[WA] Resetting screen...');
        await resetToMainScreen();
        await sleep(randomBetween(500, 800));

        // ── 2. Open chat via "Chat baru" panel ───────────────
        console.log('[WA] Opening chat for:', phone);
        const chatOpened = await openChatViaChatBaru(phone);
        if (!chatOpened) {
            chrome.runtime.sendMessage({ status: 'failed', error: 'Gagal membuka chat (Nomor mungkin tidak ada di WA)', phone });
            return;
        }

        // ── 3. Wait for chat input ───────────────────────────
        console.log('[WA] Waiting for input field...');
        const input = await waitFor(() => findMessageInput(), 10000);
        if (!input) {
            throw new Error('Input pesan tidak ditemukan setelah chat terbuka');
        }

        // ── 4. Determine Send Strategy ───────────────────────
        const store = await chrome.storage.local.get(['campaignImage']);
        const hasImage = !!store.campaignImage;

        if (hasImage) {
            // ══ STRATEGY: Image with Caption ══
            console.log('[WA] Sending image with caption...');
            
            // 5a. Paste image
            input.focus();
            await sleep(300);
            const imgFile = await dataUrlToFile(store.campaignImage);
            const dt = new DataTransfer();
            dt.items.add(imgFile);
            input.dispatchEvent(new ClipboardEvent('paste', {
                clipboardData: dt, bubbles: true, cancelable: true
            }));
            
            // 5b. Wait for preview overlay
            console.log('[WA] Waiting for image preview...');
            await sleep(2500);

            // 5c. Type caption in preview
            const captionInput = await waitFor(() => findCaptionInput(), 6000);
            if (captionInput) {
                console.log('[WA] Pasting caption...');
                captionInput.focus();
                await sleep(300);
                await pasteText(captionInput, message);
                await sleep(500);
                
                // 5d. Send (via Enter)
                console.log('[WA] Sending via Preview Enter...');
                await pressPreviewSend();
            } else {
                console.warn('[WA] Caption field not found, sending image only');
                await pressPreviewSend();
            }

        } else {
            // ══ STRATEGY: Text Only ══
            console.log('[WA] Pasting message...');
            input.focus();
            await sleep(300);
            await pasteText(input, message);
            await sleep(500);
            
            // Send (via Enter)
            console.log('[WA] Sending via Main Enter...');
            await pressSend();
        }

        // ── 6. Wrap Up ───────────────────────────────────────
        await sleep(randomBetween(1000, 2000));
        console.log(`[WA] ✅ Successfully sent to ${phone}`);
        chrome.runtime.sendMessage({ status: 'sent', phone });

    } catch (err) {
        console.error('[WA] ❌ Error:', err.message);
        chrome.runtime.sendMessage({ status: 'failed', error: err.message, phone });
    } finally {
        isProcessing = false;
        clearTimeout(processTimeout);
        console.log('[WA] Ready for next message');
    }
}

// ══════════════════════════════════════════════════════════════
//  RESET TO MAIN SCREEN
// ══════════════════════════════════════════════════════════════
async function resetToMainScreen() {
    // Press Escape to close any modals
    for (let i = 0; i < 3; i++) {
        document.dispatchEvent(new KeyboardEvent('keydown', {
            key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true
        }));
        await sleep(250);
    }

    // Click back button if "Chat baru" panel is still open
    const backBtn = document.querySelector('button[aria-label="Kembali"]')
        || document.querySelector('button[aria-label="Back"]');
    if (backBtn) {
        backBtn.click();
        await sleep(500);
    }

    // Clear search if active
    const clearBtn = document.querySelector('span[data-icon="x-alt"]');
    if (clearBtn) {
        clickEl(clearBtn);
        await sleep(400);
    }
}

// ══════════════════════════════════════════════════════════════
//  OPEN CHAT VIA "CHAT BARU" PANEL
//  This is the ONLY way to message unsaved numbers!
//  Flow: Click ⊞ → Type number → See "Tidak ada di daftar kontak"
//        → Click the result → Chat opens
// ══════════════════════════════════════════════════════════════
async function openChatViaChatBaru(phone) {
    // ── Step 1: Click the "Chat baru" (⊞) button ────────────
    // It's in the header, to the left of the three-dot menu
    const newChatBtn = document.querySelector('button[aria-label="Chat baru"]')
        || document.querySelector('button[aria-label="New chat"]')
        || document.querySelector('[data-testid="chat-list-header-btn-new-chat"]');

    if (!newChatBtn) {
        // Fallback: look for the ⊞ icon by data-icon
        const icon = document.querySelector('span[data-icon="new-chat-outline"]')
            || document.querySelector('span[data-icon="new-chat"]');
        if (icon) {
            clickEl(icon);
        } else {
            console.error('[WA] ✘ "Chat baru" button not found!');
            logAvailableButtons();
            return false;
        }
    } else {
        newChatBtn.click();
    }

    console.log('[WA] ✓ Clicked "Chat baru"');
    await sleep(1200);

    // ── Step 2: Find the search input in the "Chat baru" panel
    // The panel shows: "Cari nama atau nomor" / "Search name or number"
    const searchInput = await waitFor(() => findChatBaruSearchInput(), 5000);
    if (!searchInput) {
        console.error('[WA] ✘ Search input in "Chat baru" not found');
        logAvailableInputs();
        await goBack();
        return false;
    }
    console.log('[WA] ✓ Search input found in "Chat baru" panel');

    // ── Step 3: Clear and type the phone number ──────────────
    searchInput.focus();
    searchInput.click();
    await sleep(300);

    // Clear existing text
    if (searchInput.tagName === 'INPUT') {
        searchInput.value = '';
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
        document.execCommand('selectAll', false, null);
        document.execCommand('delete', false, null);
    }
    await sleep(200);

    // Type the phone number (raw digits work: 628xxx)
    if (searchInput.tagName === 'INPUT') {
        // For <input> elements: set value + dispatch events
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value'
        ).set;
        nativeInputValueSetter.call(searchInput, phone);
        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
        searchInput.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
        // For contenteditable: use insertText
        document.execCommand('insertText', false, phone);
    }
    console.log('[WA] Typed in search:', phone);

    // ── Step 4: Wait for results to appear ───────────────────
    // Results appear under "Tidak ada di daftar kontak Anda" for unsaved numbers
    await sleep(3000);

    // ── Step 5: Click the result ─────────────────────────────
    const clicked = await clickChatBaruResult(phone);
    if (!clicked) {
        console.error('[WA] ✘ No result found for', phone);
        await goBack();
        return false;
    }

    console.log('[WA] ✓ Chat result clicked, waiting for chat to open...');
    await sleep(1500);
    return true;
}

// ══════════════════════════════════════════════════════════════
//  FIND SEARCH INPUT IN "CHAT BARU" PANEL
// ══════════════════════════════════════════════════════════════
function findChatBaruSearchInput() {
    // Priority 1: Input with specific aria-label (Indonesian)
    let el = document.querySelector('input[aria-label="Cari nama atau nomor"]');
    if (el) return el;

    // Priority 2: Input with English aria-label
    el = document.querySelector('input[aria-label="Search name or number"]');
    if (el) return el;

    // Priority 3: Any input with search-related placeholder/label in the panel
    const inputs = document.querySelectorAll('input');
    for (const inp of inputs) {
        const label = (inp.getAttribute('aria-label') || inp.placeholder || '').toLowerCase();
        if (label.includes('cari') || label.includes('search') || label.includes('nama') || label.includes('name') || label.includes('nomor') || label.includes('number')) {
            return inp;
        }
    }

    // Priority 4: Contenteditable with data-tab="3" (older WhatsApp versions)
    el = document.querySelector('div[contenteditable="true"][data-tab="3"]');
    if (el) return el;

    // Priority 5: Any contenteditable with search-related attributes
    const editables = document.querySelectorAll('div[contenteditable="true"]');
    for (const e of editables) {
        const ph = (e.getAttribute('aria-placeholder') || e.getAttribute('title') || '').toLowerCase();
        if (ph.includes('cari') || ph.includes('search') || ph.includes('nama') || ph.includes('nomor')) {
            return e;
        }
    }

    return null;
}

// ══════════════════════════════════════════════════════════════
//  CLICK RESULT IN "CHAT BARU" PANEL
//  Result appears under "Tidak ada di daftar kontak Anda"
//  as a div[role="button"] or clickable row with the phone number
// ══════════════════════════════════════════════════════════════
async function clickChatBaruResult(phone) {
    const digits = phone.replace(/\D/g, '');
    const last8 = digits.slice(-8);

    for (let attempt = 0; attempt < 5; attempt++) {
        console.log(`[WA] Looking for result... attempt ${attempt + 1}`);

        // Strategy 1: Look for div[role="button"] containing our phone digits
        // This is the exact element type seen in the WhatsApp Business DOM
        const roleButtons = document.querySelectorAll('div[role="button"]');
        for (const btn of roleButtons) {
            const txt = (btn.textContent || '').replace(/\D/g, '');
            if (txt.includes(last8) || txt.includes(digits)) {
                console.log('[WA] ★ Found result as role="button"');
                btn.click();
                await sleep(300);
                return true;
            }
        }

        // Strategy 2: Look for any element after "Tidak ada di daftar kontak"
        // or "Not in your contacts" header
        const allElements = document.querySelectorAll('span, div');
        let foundHeader = false;
        for (const el of allElements) {
            const txt = (el.textContent || '').trim();

            // Check if this is the "not in contacts" header
            if (txt.includes('Tidak ada di daftar kontak') || txt.includes('Not in your contacts')) {
                foundHeader = true;
                continue;
            }

            // If we passed the header, look for a clickable element with phone digits
            if (foundHeader && txt.length > 3 && txt.length < 50) {
                const elDigits = txt.replace(/\D/g, '');
                if (elDigits.includes(last8)) {
                    // Found! Click the closest clickable parent
                    const clickTarget = el.closest('[role="button"]')
                        || el.closest('[role="listitem"]')
                        || el.closest('[role="row"]')
                        || el.closest('[role="option"]')
                        || el.closest('div[tabindex]')
                        || el.closest('div');
                    if (clickTarget) {
                        console.log('[WA] ★ Found result after "Tidak ada di daftar kontak"');
                        clickTarget.click();
                        await sleep(300);
                        return true;
                    }
                }
            }
        }

        // Strategy 3: Look for gridcell with phone digits
        const gridCells = document.querySelectorAll('[role="gridcell"]');
        for (const cell of gridCells) {
            const txt = (cell.textContent || '').replace(/\D/g, '');
            if (txt.includes(last8)) {
                console.log('[WA] ★ Found result in gridcell');
                cell.click();
                await sleep(300);
                return true;
            }
        }

        // Strategy 4: Look for listitem, row, option with phone digits
        const rows = document.querySelectorAll('[role="listitem"], [role="row"], [role="option"], [data-testid="cell-frame-container"]');
        for (const row of rows) {
            const txt = (row.textContent || '').replace(/\D/g, '');
            // Skip if it's "Grup baru" or "Kontak baru" options
            if ((row.textContent || '').includes('Grup baru') || (row.textContent || '').includes('Kontak baru')) continue;
            if ((row.textContent || '').includes('Kirim pesan ke diri sendiri')) continue;
            if (txt.includes(last8) || txt.includes(digits)) {
                console.log('[WA] ★ Found result in list row');
                row.click();
                await sleep(300);
                return true;
            }
        }

        // Strategy 5: Look for any clickable element with phone number text
        // WhatsApp shows +62 821-5432-8438 format
        const formatted = '+' + digits.replace(/(\d{2})(\d{3})(\d{4})(\d{4})/, '$1 $2-$3-$4');
        const spans = document.querySelectorAll('span');
        for (const span of spans) {
            const txt = (span.textContent || '').trim();
            if (txt.includes(formatted) || (txt.replace(/\D/g, '').includes(last8) && txt.startsWith('+'))) {
                const clickTarget = span.closest('[role="button"]')
                    || span.closest('[role="listitem"]')
                    || span.closest('[tabindex]')
                    || span.parentElement?.parentElement;
                if (clickTarget) {
                    console.log('[WA] ★ Found formatted number span');
                    clickTarget.click();
                    await sleep(300);
                    return true;
                }
            }
        }

        await sleep(800);
    }

    return false;
}

// ══════════════════════════════════════════════════════════════
//  FIND MESSAGE INPUT (in the right panel footer)
//  Label: "Ketik pesan" / "Type a message"
// ══════════════════════════════════════════════════════════════
function findMessageInput() {
    // Strategy 1: Exact aria-label match (Indonesian)
    let el = document.querySelector('div[contenteditable="true"][aria-label^="Ketik pesan"]');
    if (el) return el;

    // Strategy 2: Exact aria-label match (English)
    el = document.querySelector('div[contenteditable="true"][aria-label^="Type a message"]');
    if (el) return el;

    // Strategy 3: data-tab="10"
    el = document.querySelector('div[contenteditable="true"][data-tab="10"]');
    if (el) return el;

    // Strategy 4: role="textbox" with message-related label
    const textboxes = document.querySelectorAll('div[role="textbox"][contenteditable="true"]');
    for (const tb of textboxes) {
        const label = (tb.getAttribute('aria-label') || '').toLowerCase();
        if (label.includes('message') || label.includes('pesan') || label.includes('ketik') || label.includes('type')) {
            return tb;
        }
    }

    // Strategy 5: footer contenteditable
    const footer = document.querySelector('footer');
    if (footer) {
        el = footer.querySelector('div[contenteditable="true"]');
        if (el) return el;
    }

    // Strategy 6: In #main panel
    const main = document.getElementById('main');
    if (main) {
        el = main.querySelector('div[contenteditable="true"]');
        if (el) return el;
    }

    return null;
}

// ══════════════════════════════════════════════════════════════
//  TYPE / PASTE
// ══════════════════════════════════════════════════════════════
async function pasteText(input, message) {
    input.focus();
    await sleep(100);
    selectAllDel();
    await sleep(100);

    // Method 1: ClipboardEvent paste
    const dt = new DataTransfer();
    dt.setData('text/plain', message);
    input.dispatchEvent(new ClipboardEvent('paste', {
        clipboardData: dt, bubbles: true, cancelable: true
    }));
    await sleep(400);
    if (hasText(input)) return;

    // Method 2: execCommand
    input.focus();
    document.execCommand('insertText', false, message);
    await sleep(400);
    if (hasText(input)) return;

    // Method 3: innerHTML
    input.innerHTML = `<span>${escapeHtml(message)}</span>`;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    await sleep(300);
}

async function typeCharByChar(input, message) {
    input.focus();
    await sleep(200);
    selectAllDel();
    await sleep(200);

    for (const char of message) {
        if (char === '\n') {
            input.dispatchEvent(new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13, shiftKey: true, bubbles: true
            }));
            document.execCommand('insertLineBreak');
            await sleep(randomBetween(150, 400));
        } else {
            document.execCommand('insertText', false, char);
            await sleep(' .,!?'.includes(char) ? randomBetween(60, 180) : randomBetween(20, 70));
            if (Math.random() < 0.015) await sleep(randomBetween(400, 1000));
        }
    }
    await sleep(randomBetween(250, 550));
}

// ══════════════════════════════════════════════════════════════
//  SEND BUTTON — "Kirim" / "Send"
// ══════════════════════════════════════════════════════════════
async function pressSend() {
    const input = findMessageInput();
    if (input) {
        input.focus();
        const event = new KeyboardEvent('keydown', {
            key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
            bubbles: true, cancelable: true
        });
        input.dispatchEvent(event);
        console.log('[WA] Send via Enter key ✓');
        return true;
    }
    console.error('[WA] Cannot send: message input not found');
    return false;
}

// (sendImage removed — image logic is now in handleSendMessage)

// ══════════════════════════════════════════════════════════════
//  PRESS SEND IN IMAGE PREVIEW OVERLAY
//  This is a SEPARATE send button from the main chat send/mic!
// ══════════════════════════════════════════════════════════════
async function pressPreviewSend() {
    // Wait up to 5 seconds for the preview to be ready
    for (let i = 0; i < 10; i++) {
        const captionInput = findCaptionInput();
        if (captionInput) {
            captionInput.focus();
            const event = new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13, which: 13,
                bubbles: true, cancelable: true
            });
            captionInput.dispatchEvent(event);
            console.log('[WA] Preview send via Enter key ✓');
            
            // Wait to see if preview closes
            await sleep(1000);
            if (!document.querySelector('[data-testid="media-editor"]')) {
                return true;
            }
        }
        await sleep(500);
    }

    // Last resort: click any Send button outside footer
    const btn = document.querySelector('button[aria-label="Kirim"]:not(footer button)')
             || document.querySelector('button[aria-label="Send"]:not(footer button)')
             || document.querySelector('span[data-icon="send"]:not(footer span)')?.closest('button');
    if (btn) {
        btn.click();
        return true;
    }

    return false;
}

// ══════════════════════════════════════════════════════════════
//  CONVERT DATA URL TO FILE
// ══════════════════════════════════════════════════════════════
async function dataUrlToFile(dataUrl) {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    return new File([blob], 'image.png', { type: blob.type || 'image/png' });
}

// ══════════════════════════════════════════════════════════════
//  FIND CAPTION INPUT IN IMAGE PREVIEW OVERLAY
//  When you paste an image, WhatsApp shows a preview with a
//  text input at the bottom for adding a caption
// ══════════════════════════════════════════════════════════════
function findCaptionInput() {
    // Strategy 1: Search specifically within the media preview containers
    const previewContainer = document.querySelector('[data-testid="media-editor"]')
        || document.querySelector('[data-testid="image-editor"]')
        || document.querySelector('[data-testid="media-preview"]');
    
    if (previewContainer) {
        const inContainer = previewContainer.querySelector('div[contenteditable="true"]');
        if (inContainer) return inContainer;
    }

    // Strategy 2: Search globally for any visible contenteditable that is NOT in the footer
    const editables = document.querySelectorAll('div[contenteditable="true"]');
    for (const el of editables) {
        // CRITICAL: Caption input in preview is NEVER in the footer
        if (el.closest('footer')) continue;
        
        // Skip search input (usually has data-tab="3")
        if (el.getAttribute('data-tab') === '3') continue;

        // Must be visible
        if (el.offsetParent === null) continue;

        const label = (el.getAttribute('aria-label') || el.innerText || el.getAttribute('aria-placeholder') || '').toLowerCase();
        if (label.includes('pesan') || label.includes('message') || label.includes('caption') || label.includes('keterangan')) {
            return el;
        }
    }

    return null;
}

// ══════════════════════════════════════════════════════════════
//  UTILITIES
// ══════════════════════════════════════════════════════════════
function goBack() {
    const btn = document.querySelector('button[aria-label="Kembali"]')
        || document.querySelector('button[aria-label="Back"]')
        || document.querySelector('span[data-icon="back"]');
    if (btn) {
        if (btn.tagName === 'BUTTON') btn.click();
        else clickEl(btn);
    } else {
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
    }
    return sleep(500);
}

function clickEl(el) {
    const target = el.closest('button') || el.closest('[role="button"]') || el;
    target.click();
}

function selectAllDel() {
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
}

function hasText(el) {
    return (el.textContent || '').trim().length > 0;
}

function escapeHtml(text) {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
}

async function waitFor(finder, timeout) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        const el = finder();
        if (el) return el;
        await sleep(400);
    }
    return null;
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

function randomBetween(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Debug helpers
function logAvailableButtons() {
    const buttons = document.querySelectorAll('button');
    console.log('[WA-DEBUG] Buttons:', Array.from(buttons).map(b => ({
        label: b.getAttribute('aria-label'),
        testId: b.getAttribute('data-testid'),
        text: (b.textContent || '').slice(0, 30)
    })));
}

function logAvailableInputs() {
    const inputs = document.querySelectorAll('input');
    console.log('[WA-DEBUG] Inputs:', Array.from(inputs).map(i => ({
        type: i.type,
        label: i.getAttribute('aria-label'),
        placeholder: i.placeholder
    })));
    const editables = document.querySelectorAll('div[contenteditable="true"]');
    console.log('[WA-DEBUG] Editables:', Array.from(editables).map(e => ({
        tab: e.getAttribute('data-tab'),
        label: e.getAttribute('aria-label') || e.getAttribute('aria-placeholder'),
        role: e.getAttribute('role')
    })));
}
