document.addEventListener("DOMContentLoaded", function () {
  const postMessage = document.getElementById("postMessage");
  const photoInput = document.getElementById("photoInput");
  const photoPreview = document.getElementById("photoPreview");
  const newGroupUrl = document.getElementById("newGroupUrl");
  const addGroupButton = document.getElementById("addGroup");
  const scrapeGroupsButton = document.getElementById("scrapeGroups");
  const saveSettingsButton = document.getElementById("saveSettings");
  const groupList = document.getElementById("groupList");
  const checkAll = document.getElementById("checkAll");
  const statusDiv = document.getElementById("status");

  let groups = [];
  let photoFiles = [];

  // Muat data dari storage
  chrome.storage.local.get(
    ["postMessage", "groups", "selectedGroups"],
    function (result) {
      if (result.postMessage) {
        postMessage.value = result.postMessage;
      }

      if (result.groups) {
        groups = result.groups;
        renderGroups();
      }

      if (result.selectedGroups) {
        // Setel checkbox yang dipilih
        setTimeout(() => {
          const checkboxes = document.querySelectorAll(
            'input[name="selectedGroups"]'
          );
          checkboxes.forEach((checkbox) => {
            checkbox.checked = result.selectedGroups.includes(checkbox.value);
          });
          syncCheckAll();
        }, 100);
      }
    }
  );

  // Preview foto
  photoInput.addEventListener("change", function () {
    photoPreview.innerHTML = "";
    photoFiles = Array.from(this.files).slice(0, 10); // Maksimal 10 file

    photoFiles.forEach((file, index) => {
      if (index >= 10) return;

      const reader = new FileReader();
      reader.onload = function (e) {
        const img = document.createElement("img");
        img.src = e.target.result;
        img.className = "photo-preview";
        img.title = file.name;
        photoPreview.appendChild(img);
      };
      reader.readAsDataURL(file);
    });
  });

  // Tambah grup
  addGroupButton.addEventListener("click", function () {
    const url = newGroupUrl.value.trim();
    if (url && !groups.includes(url)) {
      groups.push(url);
      renderGroups();
      newGroupUrl.value = "";
      showStatus("Grup berhasil ditambahkan", "success");
    }
  });

  // Scrape grup
  scrapeGroupsButton.addEventListener("click", function () {
    showStatus("Mengambil daftar grup...", "info");

    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentTab = tabs[0];

      if (!currentTab.url.includes("facebook.com")) {
        showStatus("Harap buka Facebook terlebih dahulu", "error");
        return;
      }

      chrome.tabs.sendMessage(
        currentTab.id,
        { action: "scrapeGroups" },
        function (response) {
          if (response && response.success) {
            // Tambahkan grup baru yang belum ada
            const newGroups = response.groups.filter(
              (url) => !groups.includes(url)
            );
            groups = [...groups, ...newGroups];
            renderGroups();
            showStatus(
              `Berhasil menambahkan ${newGroups.length} grup baru`,
              "success"
            );
          } else {
            showStatus(
              "Gagal mengambil grup: " +
                (response ? response.error : "Tidak ada respons"),
              "error"
            );
          }
        }
      );
    });
  });

  // Simpan pengaturan
  saveSettingsButton.addEventListener("click", function () {
    const selectedGroups = Array.from(
      document.querySelectorAll('input[name="selectedGroups"]:checked')
    ).map((checkbox) => checkbox.value);

    const settings = {
      postMessage: postMessage.value,
      groups: groups,
      selectedGroups: selectedGroups,
      photoFiles: photoFiles,
    };

    chrome.storage.local.set(settings, function () {
      showStatus("Pengaturan berhasil disimpan", "success");
    });
  });

  // Render daftar grup
  function renderGroups() {
    groupList.innerHTML = "";

    groups.forEach((url, index) => {
      const div = document.createElement("div");
      div.className = "group-item";
      div.innerHTML = `
        <input type="checkbox" name="selectedGroups" value="${url}" id="group${index}">
        <label for="group${index}">${url}</label>
        <button onclick="deleteGroup(${index})">Hapus</button>
      `;
      groupList.appendChild(div);
    });

    syncCheckAll();
  }

  // Tampilkan status
  function showStatus(message, type) {
    statusDiv.textContent = message;
    statusDiv.className = type;
    setTimeout(() => {
      statusDiv.textContent = "";
      statusDiv.className = "";
    }, 3000);
  }

  // Sync checkbox "Pilih Semua"
  function syncCheckAll() {
    const checkboxes = document.querySelectorAll(
      'input[name="selectedGroups"]'
    );
    checkAll.checked =
      checkboxes.length > 0 && Array.from(checkboxes).every((cb) => cb.checked);
  }

  // Hapus grup
  window.deleteGroup = function (index) {
    groups.splice(index, 1);
    renderGroups();
    showStatus("Grup berhasil dihapus", "success");
  };

  // Toggle semua grup
  window.toggleAllGroups = function (checkbox) {
    const checkboxes = document.querySelectorAll(
      'input[name="selectedGroups"]'
    );
    checkboxes.forEach((cb) => (cb.checked = checkbox.checked));
  };
});
