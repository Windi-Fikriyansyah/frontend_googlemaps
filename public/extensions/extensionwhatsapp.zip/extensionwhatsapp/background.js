/* background.js - WhatsApp Premium Sender (BULLETPROOF MV3) */
console.log('[WA-BG] Bulletproof worker loaded');

const ALARM_NAME = 'campaign_loop';

// Persistence helpers
async function getCampaign() {
    const data = await chrome.storage.local.get(['currentCampaign']);
    return data.currentCampaign || null;
}

async function saveCampaign(state) {
    await chrome.storage.local.set({ currentCampaign: state });
}

// ══════════════════════════════════════════════════════════════
//  MESSAGE LISTENER
// ══════════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[WA-BG] Incoming Message:', request.action || request.status);

    if (request.action === 'startCampaign') {
        const campaign = {
            records: request.records,
            index: 0,
            isRunning: true,
            tabId: request.tabId,
            settings: request.settings,
            sent: 0,
            failed: 0,
            startTime: Date.now()
        };
        saveCampaign(campaign).then(() => {
            console.log(`[WA-BG] Campaign setup finished for ${campaign.records.length} numbers`);
            processNext();
        });
        sendResponse({ status: 'started' });
        return false;

    } else if (request.action === 'stopCampaign') {
        chrome.alarms.clear(ALARM_NAME);
        getCampaign().then(campaign => {
            if (campaign) {
                campaign.isRunning = false;
                saveCampaign(campaign);
            }
        });
        sendResponse({ status: 'stopped' });

    } else if (request.action === 'getCampaignStatus') {
        getCampaign().then(campaign => {
            if (campaign) {
                sendResponse({
                    isRunning: campaign.isRunning,
                    sent: campaign.sent,
                    failed: campaign.failed,
                    total: campaign.records.length,
                    index: campaign.index
                });
            } else {
                sendResponse({ isRunning: false });
            }
        });
        return true;

    } else if (request.status === 'sent' || request.status === 'failed') {
        handleResult(request);
        sendResponse({ received: true });
    }

    return true;
});

// ══════════════════════════════════════════════════════════════
//  HANDLE RESULTS (SENT/FAILED)
// ══════════════════════════════════════════════════════════════
async function handleResult(request) {
    const campaign = await getCampaign();
    if (!campaign || !campaign.isRunning) return;

    const success = request.status === 'sent';
    if (success) {
        campaign.sent++;
    } else {
        campaign.failed++;
    }

    console.log(`[WA-BG] Item #${campaign.index + 1} processed: ${request.status}`);

    try {
        chrome.runtime.sendMessage({
            action: 'updateProgress',
            result: { success, error: request.error || '', phone: request.phone },
            sent: campaign.sent,
            failed: campaign.failed,
            total: campaign.records.length
        }).catch(() => {});
    } catch (e) {}

    // Move to next index
    campaign.index++;
    await saveCampaign(campaign);
    scheduleNext(campaign);
}

// ══════════════════════════════════════════════════════════════
//  SCHEDULING
// ══════════════════════════════════════════════════════════════
async function scheduleNext(campaign) {
    if (!campaign.isRunning || campaign.index >= campaign.records.length) {
        finishCampaign();
        return;
    }

    const min = Math.max(1, parseInt(campaign.settings.minDelay) || 5);
    const max = Math.max(min, parseInt(campaign.settings.maxDelay) || 15);
    const delaySeconds = Math.floor(Math.random() * (max - min + 1)) + min;
    
    console.log(`[WA-BG] Next in ${delaySeconds}s (Next Index: ${campaign.index})`);

    // Safety alarm for MV3 persistence
    chrome.alarms.create(ALARM_NAME, { delayInMinutes: 1 });
    
    setTimeout(() => {
        executeNext();
    }, delaySeconds * 1000);
}

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === ALARM_NAME) {
        executeNext();
    }
});

async function executeNext() {
    const campaign = await getCampaign();
    if (campaign && campaign.isRunning && campaign.index < campaign.records.length) {
        processNext();
    }
}

async function finishCampaign() {
    console.log('[WA-BG] Campaign finished');
    chrome.alarms.clear(ALARM_NAME);
    const campaign = await getCampaign();
    if (campaign) {
        campaign.isRunning = false;
        await saveCampaign(campaign);
        try { chrome.runtime.sendMessage({ action: 'campaignFinished' }).catch(() => {}); } catch (e) {}
    }
}

// ══════════════════════════════════════════════════════════════
//  PROCESS NEXT
// ══════════════════════════════════════════════════════════════
async function processNext() {
    const campaign = await getCampaign();
    if (!campaign || !campaign.isRunning || campaign.index >= campaign.records.length) return;

    const record = campaign.records[campaign.index];
    const phone = record._phone;
    
    // Format message
    let message = campaign.settings.template;
    for (const key in record) {
        if (key !== '_phone') {
            message = message.replace(new RegExp(`\\{${key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\}`, 'gi'), record[key] || '');
        }
    }

    if (campaign.settings.antiSpam) {
        const zwc = ['\u200B', '\u200C', '\u200D', '\uFEFF'];
        message += zwc[Math.floor(Math.random() * zwc.length)];
    }

    console.log(`[WA-BG] → Messaging ${phone} (#${campaign.index + 1})`);

    try {
        chrome.alarms.clear(ALARM_NAME);

        chrome.tabs.sendMessage(campaign.tabId, {
            action: 'sendMessage',
            phone, message,
            typingSim: campaign.settings.randomTyping
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.warn('[WA-BG] Tab unreachable, attempting re-injection');
                handleReinjection(campaign, phone, message);
                return;
            }

            // Handle BUSY status from content script
            if (response && response.status === 'busy') {
                console.warn('[WA-BG] Tab is busy, retrying in 5s...');
                setTimeout(processNext, 5000);
            }
        });
    } catch (err) {
        console.error('[WA-BG] Tab interaction error:', err.message);
        // Maybe tab was closed
    }
}

async function handleReinjection(campaign, phone, message) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId: campaign.tabId },
            files: ['content.js']
        });
        
        setTimeout(() => {
            chrome.tabs.sendMessage(campaign.tabId, {
                action: 'sendMessage',
                phone, message,
                typingSim: campaign.settings.randomTyping
            });
        }, 2000);
    } catch (e) {
        console.error('[WA-BG] Reinjection failed');
        handleResult({ status: 'failed', error: 'Script not loaded', phone });
    }
}
