/**
 * ScrapeMaps - Content Script
 * Injected into Google Maps pages
 * Handles auto-scroll and enhanced scraping
 */

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'ping') {
    sendResponse({ status: 'ok' });
  }

  if (message.action === 'autoScroll') {
    autoScrollAndScrape(message.maxResults || 100)
      .then(data => sendResponse({ data }))
      .catch(err => sendResponse({ error: err.message }));
    return true; // async response
  }
});

/**
 * Auto-scroll the results panel to load more businesses
 */
async function autoScrollAndScrape(maxResults) {
  const feed = document.querySelector('[role="feed"]');
  if (!feed) {
    throw new Error('Tidak menemukan panel hasil pencarian.');
  }

  const scrollContainer = feed.closest('[role="main"]')?.querySelector('.m6QErb[aria-label]')
    || feed.closest('.m6QErb')
    || feed.parentElement;

  if (!scrollContainer) {
    throw new Error('Tidak menemukan container scroll.');
  }

  let previousCount = 0;
  let sameCountTries = 0;

  while (sameCountTries < 3) {
    // Scroll down
    scrollContainer.scrollTop = scrollContainer.scrollHeight;
    await new Promise(r => setTimeout(r, 2000));

    const currentItems = document.querySelectorAll('[role="feed"] > div > div > a[href*="/maps/place/"]');
    const currentCount = currentItems.length;

    if (currentCount >= maxResults) break;

    if (currentCount === previousCount) {
      sameCountTries++;
    } else {
      sameCountTries = 0;
    }
    previousCount = currentCount;

    // Check if end of results
    const endMsg = document.querySelector('.m6QErb .HlvSq');
    if (endMsg) break;
  }

  return true;
}
