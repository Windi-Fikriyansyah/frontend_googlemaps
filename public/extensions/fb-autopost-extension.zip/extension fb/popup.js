let stopScraping = false;
document.getElementById("stopScrapeBtn").addEventListener("click", async () => {
  showStatus("⏹ Proses ambil grup dihentikan!", "error");

  // kirim pesan stop ke tab aktif Facebook
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { action: "stopScraping" });
});

// Global variables
let groups = [];
let selectedPhotos = [];

// Initialize popup
document.addEventListener("DOMContentLoaded", function () {
  loadGroups();
  loadSavedData();

  // Setup photo preview
  document
    .getElementById("photoInput")
    .addEventListener("change", handlePhotoSelect);

  // Setup button event listeners
  document.getElementById("saveBtn").addEventListener("click", saveData);
  document.getElementById("scrapeBtn").addEventListener("click", scrapeGroups);
  document.getElementById("runBotBtn").addEventListener("click", runBot);
  document
    .getElementById("selectAll")
    .addEventListener("change", toggleAllGroups);

  document
    .getElementById("clearGroupsBtn")
    .addEventListener("click", clearAllGroups);
});

function toBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// Handle photo selection
function handlePhotoSelect(event) {
  const files = Array.from(event.target.files);
  selectedPhotos = files.slice(0, 10); // Limit to 10 photos

  const preview = document.getElementById("photoPreview");
  preview.innerHTML = "";

  selectedPhotos.forEach((file, index) => {
    const reader = new FileReader();
    reader.onload = function (e) {
      const img = document.createElement("img");
      img.src = e.target.result;
      img.title = file.name;
      preview.appendChild(img);
    };
    reader.readAsDataURL(file);
  });
}

// Load saved groups from storage
async function loadGroups() {
  try {
    const result = await chrome.storage.local.get(["groups"]);
    groups = result.groups || [];
    renderGroups();
  } catch (error) {
    showStatus("Gagal memuat grup: " + error.message, "error");
  }
}

// Load saved form data
async function loadSavedData() {
  try {
    const result = await chrome.storage.local.get([
      "postMessage",
      "newGroupUrl",
    ]);

    if (result.postMessage) {
      document.getElementById("postMessage").value = result.postMessage;
    }

    if (result.newGroupUrl) {
      document.getElementById("newGroupUrl").value = result.newGroupUrl;
    }
  } catch (error) {
    console.error("Failed to load saved data:", error);
  }
}

// Render groups list
function renderGroups() {
  const groupList = document.getElementById("groupList");
  const groupCount = document.getElementById("groupCount");

  if (groups.length === 0) {
    groupList.innerHTML = `
            <div style="text-align: center; color: #666; padding: 20px;">
                Belum ada grup. Klik "Ambil Grup" untuk mengambil daftar grup Anda.
            </div>
        `;
    groupCount.textContent = "0 grup";
    return;
  }

  groupList.innerHTML = "";
  groupCount.textContent = `${groups.length} grup`;

  groups.forEach((group, index) => {
    const div = document.createElement("div");
    div.className = "group-item";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.id = `group${index}`;
    checkbox.dataset.index = index;
    checkbox.checked = true;

    const link = document.createElement("a");
    link.href = group.url;
    link.target = "_blank";
    link.className = "group-url";
    link.title = group.url;
    link.textContent =
      group.url
        .replace("https://www.facebook.com/groups/", "")
        .substring(0, 30) + "...";

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "🗑️";
    deleteBtn.style.cssText =
      "background:none;border:none;cursor:pointer;margin-left:5px;";
    deleteBtn.title = "Hapus grup";
    deleteBtn.addEventListener("click", () => deleteGroup(index));

    div.appendChild(checkbox);
    div.appendChild(link);
    div.appendChild(deleteBtn);

    groupList.appendChild(div);
  });
}

// Toggle all groups selection
function toggleAllGroups() {
  const selectAll = document.getElementById("selectAll");
  const checkboxes = document.querySelectorAll(
    '#groupList input[type="checkbox"]'
  );

  checkboxes.forEach((checkbox) => {
    checkbox.checked = selectAll.checked;
  });
}

// Save form data
async function saveData() {
  try {
    const postMessage = document.getElementById("postMessage").value;
    const newGroupUrl = document.getElementById("newGroupUrl").value;

    // Save to storage
    await chrome.storage.local.set({
      postMessage,
      newGroupUrl,
    });

    // Add new group if provided
    if (
      newGroupUrl.trim() &&
      !groups.some((g) => g.url === newGroupUrl.trim())
    ) {
      groups.push({ url: newGroupUrl.trim() });
      await chrome.storage.local.set({ groups });
      renderGroups();
      document.getElementById("newGroupUrl").value = "";
    }

    showStatus("✅ Data berhasil disimpan!", "success");
  } catch (error) {
    showStatus("❌ Gagal menyimpan: " + error.message, "error");
  }
}

// Scrape groups from Facebook
async function scrapeGroups() {
  stopScraping = false; // reset setiap mulai
  document.getElementById("scrapeProgressContainer").style.display = "block";
  document.getElementById("scrapeProgress").style.width = "0%";
  document.getElementById("scrapeProgress").textContent = "0%";

  try {
    showStatus("🔍 Mengambil daftar grup...", "info");

    const [tab] = await chrome.tabs.query({
      active: true,
      currentWindow: true,
    });

    if (!tab.url.includes("facebook.com")) {
      showStatus("⚠️ Buka Facebook terlebih dahulu!", "error");
      document.getElementById("scrapeProgressContainer").style.display = "none";
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scrapeGroupsFromPage,
    });

    const scrapedGroups = results[0].result;

    if (scrapedGroups.length > 0) {
      let newGroupsCount = 0;
      scrapedGroups.forEach((url) => {
        if (!groups.some((g) => g.url === url)) {
          groups.push({ url });
          newGroupsCount++;
        }
      });
      await chrome.storage.local.set({ groups });
      renderGroups();
      showStatus(
        `✅ Berhasil menambahkan ${newGroupsCount} grup baru!`,
        "success"
      );
    } else {
      showStatus("⚠️ Tidak ditemukan grup di halaman ini", "error");
    }

    document.getElementById("scrapeProgressContainer").style.display = "none";
  } catch (error) {
    showStatus("❌ Gagal mengambil grup: " + error.message, "error");
    document.getElementById("scrapeProgressContainer").style.display = "none";
  }
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "scrapeProgress") {
    const progressDiv = document.getElementById("scrapeProgress");
    if (progressDiv) {
      progressDiv.style.width = message.data.progress + "%";
      progressDiv.textContent = `${message.data.collected} grup`;
    }
  }
});

function scrapeGroupsFromPage() {
  return new Promise((resolve) => {
    const collectedLinks = new Set();
    let stop = false;

    // Tambahkan exclusion keywords untuk path groups
    const excludedPaths = [
      "search",
      "joins",
      "discovery",
      "discover",
      "create",
      "category",
      "categories",
      "feed",
      "landing",
      "home",
      "about",
      "members",
      "events",
      "media",
      "files",
    ];

    // listen pesan stop dari popup
    chrome.runtime.onMessage.addListener((message) => {
      if (message.action === "stopScraping") {
        stop = true;
      }
    });

    // Ambil URL saat ini jika itu adalah halaman grup
    function checkCurrentUrl() {
      try {
        const url = new URL(window.location.href);
        const pathParts = url.pathname.split("/").filter(Boolean);
        if (
          ["www.facebook.com", "web.facebook.com"].includes(url.hostname) &&
          pathParts[0] === "groups" &&
          pathParts.length === 2 &&
          !excludedPaths.includes(pathParts[1])
        ) {
          const cleanLink = `${url.origin}/groups/${pathParts[1]}/`;
          collectedLinks.add(cleanLink);
        }
      } catch (e) { }
    }

    function scrollAndCollect() {
      if (stop) {
        resolve(Array.from(collectedLinks));
        return;
      }

      checkCurrentUrl();

      window.scrollBy(0, 1000);

      const mainContent = document.querySelector('div[role="main"]') || document;
      const links = Array.from(mainContent.querySelectorAll('a[href*="/groups/"]'))
        .map((a) => a.href)
        .filter((href) => {
          try {
            const url = new URL(href);
            if (
              !["www.facebook.com", "web.facebook.com"].includes(url.hostname)
            )
              return false;

            const pathParts = url.pathname.split("/").filter(Boolean);
            return (
              pathParts[0] === "groups" &&
              pathParts.length === 2 &&
              !excludedPaths.includes(pathParts[1])
            );
          } catch {
            return false;
          }
        })
        .map((href) => {
          const url = new URL(href);
          const pathParts = url.pathname.split("/").filter(Boolean);
          return `${url.origin}/groups/${pathParts[1]}/`;
        });

      links.forEach((link) => collectedLinks.add(link));

      // update progress
      chrome.runtime.sendMessage({
        action: "scrapeProgress",
        data: {
          collected: collectedLinks.size,
          progress: Math.min(Math.floor((collectedLinks.size / 50) * 100), 100),
        },
      });

      // Terus lakukan tanpa batas waktu, hanya berhenti jika tombol "Stop" ditekan
      setTimeout(scrollAndCollect, 2000);
    }

    scrollAndCollect();
  });
}


// Run the auto poster bot
// Run the auto poster bot
async function runBot() {
  const postMessage = document.getElementById("postMessage").value.trim();
  const selectedGroups = groups
    .filter((g, i) => document.getElementById(`group${i}`)?.checked)
    .map((g) => g.url);

  if (!postMessage || selectedGroups.length === 0) {
    showStatus("⚠️ Isi pesan dan pilih minimal 1 grup!", "error");
    return;
  }

  const photos = await Promise.all(
    selectedPhotos.map(async (file) => {
      return {
        name: file.name,
        type: file.type,
        data: await toBase64(file),
      };
    })
  );

  // Cek apakah tab Facebook sudah terbuka
  const tabs = await chrome.tabs.query({ url: "*://*.facebook.com/*" });
  if (tabs.length === 0) {
    // Jika tidak ada tab Facebook, buka tab baru
    await chrome.tabs.create({
      url: "https://www.facebook.com/",
      active: true,
    });

    // Tunggu sebentar untuk tab dimuat
    await new Promise((resolve) => setTimeout(resolve, 2000));
  } else {
    // Fokus ke tab Facebook yang sudah ada
    await chrome.tabs.update(tabs[0].id, { active: true });
  }

  // Kirim pesan ke background script untuk memulai bot
  chrome.runtime.sendMessage({
    action: "startBot",
    data: { postMessage, selectedGroups, photos },
  });

  showStatus("🚀 Bot dimulai, progress akan tampil di sini...", "info");
}

// Terima update progress dari background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "progressUpdate") {
    updateProgressUI(message.status, message.data);
  }
});

// Update progress UI
function updateProgressUI(status, data) {
  const statusDiv = document.getElementById("status");

  if (status === "posting") {
    statusDiv.innerHTML = `🚀 Posting ke grup ${data.index}/${data.total} <br><small>${data.groupUrl}</small>`;
    statusDiv.className = "status info";
  } else if (status === "success") {
    statusDiv.innerHTML = `✅ Berhasil posting di grup ${data.index}: ${data.groupUrl}`;
    statusDiv.className = "status success";
  } else if (status === "error") {
    statusDiv.innerHTML = `❌ Gagal posting di grup ${data.index}: ${data.groupUrl} <br><small>${data.error}</small>`;
    statusDiv.className = "status error";
  } else if (status === "limitReached") {
    statusDiv.innerHTML = `⚠️ Limit post nya sudah habis.<br/>Total posting yang berhasil: <b>${data.success}</b> grup.`;
    statusDiv.className = "status error";
  } else if (status === "done") {
    statusDiv.innerHTML = `🎉 Selesai! Total: ${data.total} grup`;
    statusDiv.className = "status success";
  }
}

// Show status message
function showStatus(message, type) {
  const status = document.getElementById("status");
  status.className = `status ${type}`;
  status.textContent = message;

  // Auto hide after 5 seconds
  setTimeout(() => {
    status.textContent = "";
    status.className = "";
  }, 5000);
}

// Delete group function
async function deleteGroup(index) {
  if (confirm("Yakin hapus grup ini?")) {
    try {
      groups.splice(index, 1);
      await chrome.storage.local.set({ groups });
      renderGroups();
      showStatus("✅ Grup berhasil dihapus!", "success");
    } catch (error) {
      showStatus("❌ Gagal menghapus grup: " + error.message, "error");
    }
  }
}

// Hapus semua grup
async function clearAllGroups() {
  if (confirm("Yakin ingin menghapus SEMUA grup?")) {
    try {
      groups = [];
      await chrome.storage.local.set({ groups });
      renderGroups();
      showStatus("✅ Semua grup berhasil dihapus!", "success");
    } catch (error) {
      showStatus("❌ Gagal menghapus semua grup: " + error.message, "error");
    }
  }
}
