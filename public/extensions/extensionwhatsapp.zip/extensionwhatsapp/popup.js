/* popup.js - WhatsApp Premium Sender (Anti-Ban Edition) */
document.addEventListener('DOMContentLoaded', () => {
    const excelInput = document.getElementById('excelInput');
    const fileInfo = document.getElementById('fileInfo');
    const fileNameSpan = document.getElementById('fileName');
    const rowCountSpan = document.getElementById('rowCount');
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const progressBar = document.getElementById('progressBar');
    const statusText = document.getElementById('statusText');
    const sentCountSpan = document.getElementById('sentCount');
    const failedCountSpan = document.getElementById('failedCount');
    const messageTemplate = document.getElementById('messageTemplate');
    const imageInput = document.getElementById('imageInput');

    let campaignData = [];
    let sentCount = 0;
    let failedCount = 0;
    let campaignImage = null;

    // ── Check if a campaign is already running ───────────────
    chrome.runtime.sendMessage({ action: 'getCampaignStatus' }, (response) => {
        if (chrome.runtime.lastError) return;
        if (response && response.isRunning) {
            sentCount = response.sent || 0;
            failedCount = response.failed || 0;
            updateStats();
            startBtn.disabled = true;
            stopBtn.disabled = false;
            statusText.textContent = `Campaign running... (${sentCount + failedCount}/${response.total})`;
            if (response.total > 0) {
                progressBar.style.width = `${((sentCount + failedCount) / response.total) * 100}%`;
            }
        }
    });

    // ── Image upload ─────────────────────────────────────────
    imageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (evt) => {
                campaignImage = evt.target.result;
            };
            reader.readAsDataURL(file);
        } else {
            campaignImage = null;
        }
    });

    // ── Load saved settings ──────────────────────────────────
    chrome.storage.local.get(['messageTemplate', 'minDelay', 'maxDelay', 'randomTyping', 'antiSpam'], (data) => {
        if (data.messageTemplate) messageTemplate.value = data.messageTemplate;
        if (data.minDelay) document.getElementById('minDelay').value = data.minDelay;
        if (data.maxDelay) document.getElementById('maxDelay').value = data.maxDelay;
        if (data.randomTyping !== undefined) document.getElementById('randomTyping').checked = data.randomTyping;
        if (data.antiSpam !== undefined) document.getElementById('antiSpam').checked = data.antiSpam;
    });

    // ── Excel import ─────────────────────────────────────────
    excelInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        fileNameSpan.textContent = file.name;
        const reader = new FileReader();
        reader.onload = (evt) => {
            const data = evt.target.result;
            const workbook = XLSX.read(data, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const json = XLSX.utils.sheet_to_json(worksheet, { defval: "" });
            if (json.length === 0) return;

            const headers = Object.keys(json[0]);
            let phoneKey = headers.find(c => /telepon|phone|hp|whatsapp|wa|nomor|kontak|no_hp|nohp|mobile/i.test(c));
            if (!phoneKey) {
                alert("Kolom telepon tidak ditemukan! Pastikan ada kolom bernama 'Telepon', 'Phone', 'HP', 'WhatsApp', atau 'Nomor'.");
                return;
            }

            campaignData = json.map(row => {
                const rec = { ...row };
                rec._phone = cleanPhone(row[phoneKey] || '');
                return rec;
            }).filter(item => item._phone);

            const dynamicTags = document.getElementById('dynamicTags');
            const defaultHint = document.getElementById('defaultHint');

            if (dynamicTags && defaultHint) {
                dynamicTags.innerHTML = '';
                headers.forEach(key => {
                    const span = document.createElement('span');
                    span.className = 'tag-chip';
                    span.textContent = `{${key}}`;
                    span.onclick = () => {
                        messageTemplate.value += `{${key}}`;
                    };
                    dynamicTags.appendChild(span);
                });
                dynamicTags.classList.remove('hidden');
                defaultHint.classList.add('hidden');
            }

            rowCountSpan.textContent = `| ${campaignData.length} Numbers Found`;
            fileInfo.classList.remove('hidden');
            startBtn.disabled = campaignData.length === 0;
        };
        reader.readAsBinaryString(file);
    });

    // ── Phone number cleaning ────────────────────────────────
    function cleanPhone(phone) {
        if (!phone) return null;
        let cleaned = String(phone).replace(/\D/g, '');

        // Remove leading + if any (already stripped by \D removal)
        if (cleaned.startsWith('0')) {
            cleaned = '62' + cleaned.substring(1);
        } else if (cleaned.startsWith('8')) {
            cleaned = '62' + cleaned;
        }
        // If already starts with 62, keep as is
        // Validate: Indonesian numbers should be 10-15 digits
        if (cleaned.length < 10 || cleaned.length > 15) {
            return null;
        }
        return cleaned;
    }

    // ── Start campaign ───────────────────────────────────────
    startBtn.addEventListener('click', async () => {
        const template = messageTemplate.value;
        if (!template) {
            alert('Masukkan template pesan terlebih dahulu!');
            return;
        }

        if (campaignData.length === 0) {
            alert('Upload file Excel terlebih dahulu!');
            return;
        }

        const minDelay = document.getElementById('minDelay').value;
        const maxDelay = document.getElementById('maxDelay').value;
        const randomTyping = document.getElementById('randomTyping').checked;
        const antiSpam = document.getElementById('antiSpam').checked;

        const minD = parseInt(minDelay);
        const maxD = parseInt(maxDelay);
        if (minD < 5) {
            alert('⚠️ Delay minimum harus minimal 5 detik!');
            return;
        }
        if (maxD < minD) {
            alert('Delay maximum harus lebih besar dari minimum!');
            return;
        }

        // Save current settings per campaign
        chrome.storage.local.set({
            messageTemplate: template,
            minDelay: minDelay,
            maxDelay: maxDelay,
            randomTyping: randomTyping,
            antiSpam: antiSpam,
            campaignImage: campaignImage
        });

        // 1. Get current active tab (WhatsApp)
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url || !tab.url.includes('web.whatsapp.com')) {
            alert('Buka WhatsApp Web dan pastikan Anda berada di tab tersebut sebelum menekan Start!');
            return;
        }

        console.log('[WA-Sender Popup] Verifying tab content script...');
        
        // 2. Ping tab to ensure content script is ready
        chrome.tabs.sendMessage(tab.id, { action: 'ping' }, async (response) => {
            // If No response, try to inject
            if (chrome.runtime.lastError) {
                console.warn('[WA-Sender Popup] Script not responding, injecting...');
                try {
                    await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        files: ['content.js']
                    });
                    // Wait a moment after injection
                    await new Promise(r => setTimeout(r, 1000));
                } catch (e) {
                    alert('Gagal memuat script otomatis. Silakan refresh halaman WhatsApp Web Anda.');
                    return;
                }
            }

            // 3. Start campaign in background
            chrome.runtime.sendMessage({
                action: 'startCampaign',
                tabId: tab.id,
                records: campaignData,
                settings: {
                    template: template,
                    minDelay: minDelay,
                    maxDelay: maxDelay,
                    randomTyping: randomTyping,
                    antiSpam: antiSpam
                }
            }, (startRes) => {
                if (chrome.runtime.lastError) {
                    console.error('Failed to send start message:', chrome.runtime.lastError);
                    statusText.textContent = 'Error: Background unreachable';
                    return;
                }

                console.log('[WA-Sender Popup] Campaign started response:', startRes);
                startBtn.disabled = true;
                stopBtn.disabled = false;
                sentCount = 0;
                failedCount = 0;
                updateStats();
                statusText.textContent = `Campaign started... (0/${campaignData.length})`;
                progressBar.style.width = '0%';
            });
        });
    });

    // ── Stop campaign ────────────────────────────────────────
    stopBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'stopCampaign' });
        resetUI();
        statusText.textContent = 'Campaign stopped.';
    });

    // ── Listen for updates from background ───────────────────
    chrome.runtime.onMessage.addListener((request) => {
        if (request.action === 'updateProgress') {
            sentCount = request.sent || sentCount;
            failedCount = request.failed || failedCount;

            if (request.result) {
                if (!request.sent) {
                    if (request.result.success) sentCount++;
                    else failedCount++;
                }
            }

            updateStats();

            const total = request.total || campaignData.length;
            const processed = sentCount + failedCount;
            statusText.textContent = `Processing: ${request.result.phone} (${request.result.success ? '✅ Sent' : '❌ Failed: ' + request.result.error})`;
            if (total > 0) {
                progressBar.style.width = `${(processed / total) * 100}%`;
            }

        } else if (request.action === 'campaignFinished') {
            statusText.textContent = `✅ Campaign Finished! Sent: ${sentCount}, Failed: ${failedCount}`;
            resetUI();
        }
    });

    // ── UI helpers ───────────────────────────────────────────
    function updateStats() {
        sentCountSpan.textContent = sentCount;
        failedCountSpan.textContent = failedCount;
    }

    function resetUI() {
        startBtn.disabled = campaignData.length === 0;
        stopBtn.disabled = true;
    }
});
