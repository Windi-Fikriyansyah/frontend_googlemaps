/**
 * ScrapeMaps - Background Service Worker
 * Orchestrates the scraping loop even after popup closure
 */

let scrapingState = {
  active: false,
  tabId: null,
  limit: 20,
  current: 0,
  stopRequested: false
};

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "startScrape") {
    startScraping(request.tabId, request.limit);
    sendResponse({ status: "started" });
  } else if (request.action === "stopScrape") {
    scrapingState.stopRequested = true;
    sendResponse({ status: "stopping" });
  } else if (request.action === "getState") {
    sendResponse(scrapingState);
  }
  return true;
});

async function startScraping(tabId, limit) {
  if (scrapingState.active) return;

  scrapingState = {
    active: true,
    tabId: tabId,
    limit: limit,
    current: 0,
    stopRequested: false
  };

  updateStorageState();

  try {
    // Initial scroll
    await autoScrollInTab(tabId, Math.min(limit, 10));

    if (scrapingState.stopRequested) throw new Error("Stopped");

    // Load initial scraped data list and build a set of seen URLs
    const stored = await chrome.storage.local.get(['scrapedData']);
    let allScraped = stored.scrapedData || [];
    
    // Tracking URLs we have already tried in this session to avoid infinite loops on broken items
    const attemptedUrls = new Set(allScraped.map(d => d.url).filter(u => u));
    
    let consecutiveEmptyResults = 0;

    while (allScraped.length < limit) {
        if (scrapingState.stopRequested) break;

        scrapingState.current = allScraped.length;
        updateStorageState();

        // 1. Find and click the next UNATTEMPTED item in the list
        const nextUrl = await executeInTab(tabId, findAndClickNextItem, [Array.from(attemptedUrls)]);
        
        if (!nextUrl) {
            console.log("No new items in current view, scrolling...");
            await autoScrollInTab(tabId, allScraped.length + 5);
            
            const retryUrl = await executeInTab(tabId, findAndClickNextItem, [Array.from(attemptedUrls)]);
            if (!retryUrl) {
                console.log("Reached end of list or no more unique items found.");
                break; 
            }
            // If we found something after retry, the retry function already clicked it
        }

        // Mark it as attempted immediately so we don't get stuck if it fails
        const urlToMark = nextUrl || (await executeInTab(tabId, () => window.location.href));
        if (urlToMark) attemptedUrls.add(urlToMark);

        // Wait for detail pane to load (Wait for title to change or specific element)
        await sleep(3500); 

        // 2. Scrape detail
        const detail = await executeInTab(tabId, scrapeDetailInPage);
        
        if (detail && detail.name) {
            const finalUrl = detail.url || urlToMark;
            
            // Check again if we already have this in allScraped (duplicates check)
            const isDuplicate = allScraped.some(d => d.name === detail.name && (d.address === detail.address || d.phone === detail.phone));
            
            if (!isDuplicate) {
                allScraped.push(detail);
                await chrome.storage.local.set({ scrapedData: allScraped });
                consecutiveEmptyResults = 0;
            }
        } else {
            consecutiveEmptyResults++;
            console.log(`Failed to scrape item. Consecutive failures: ${consecutiveEmptyResults}`);
            if (consecutiveEmptyResults > 15) break;
        }

        // 3. Return to results - essential to find the next item accurately
        await executeInTab(tabId, clickBackButtonInPage);
        await sleep(2000); // Wait for list to be interactive again
    }

  } catch (err) {
    console.error("Background scrape error:", err);
  } finally {
    scrapingState.active = false;
    updateStorageState();
  }
}

async function autoScrollInTab(tabId, targetCount) {
    let lastCount = 0;
    let staleTries = 0;

    for (let i = 0; i < 6; i++) { 
        if (scrapingState.stopRequested) break;
        const stats = await executeInTab(tabId, doScrollStepInPage);
        if (!stats) break;

        if (stats.itemCount >= targetCount || stats.reachedEnd) break;

        if (stats.itemCount === lastCount) {
           if (++staleTries >= 3) break;
        } else {
           staleTries = 0;
        }
        lastCount = stats.itemCount;
        await sleep(1500);
    }
}

function updateStorageState() {
  chrome.storage.local.set({ scrapingState });
}

async function executeInTab(tabId, func, args = []) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: func,
      args: args
    });
    return results?.[0]?.result;
  } catch (e) { 
    console.error("Exec error:", e);
    return null; 
  }
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// --- REUSED INPAGE FUNCTIONS ---

function findAndClickNextItem(excludeUrls) {
  const items = Array.from(document.querySelectorAll('a[href*="/maps/place/"]'));
  const excludeSet = new Set(excludeUrls);
  
  for (const item of items) {
    // Normalize URL for comparison
    const url = item.href;
    if (excludeSet.has(url)) continue;
    
    // We found an unprocessed item
    item.scrollIntoView({ block: 'center' });
    item.click();
    return url;
  }
  return null;
}

// --- REUSED INPAGE FUNCTIONS ---

function doScrollStepInPage() {
  const feed = document.querySelector('[role="feed"]');
  if (!feed) return null;
  const scrollable = feed.closest('.m6QErb[aria-label*="Results"], .m6QErb[aria-label*="Hasil"], .m6QErb') || feed.parentElement;
  if (scrollable) {
    scrollable.scrollTop = scrollable.scrollHeight;
  }
  const items = document.querySelectorAll('a[href*="/maps/place/"]');
  const endIndicators = document.querySelectorAll('.m6QErb .HlvSq, .m6QErb p span, .Pb9p9c');
  let reachedEnd = Array.from(endIndicators).some(el => {
    const t = el.textContent.toLowerCase();
    return t.includes('end of') || t.includes('tidak ada lagi') || t.includes("reached") || t.includes("akhir");
  });
  return { itemCount: items.length, reachedEnd };
}

function getItemCountInPage() {
  return document.querySelectorAll('a[href*="/maps/place/"]').length;
}

function clickListItemInPage(idx) {
  const items = document.querySelectorAll('a[href*="/maps/place/"]');
  if (items[idx]) {
    items[idx].scrollIntoView({ block: 'center' });
    items[idx].click();
    return true;
  }
  return false;
}

function clickBackButtonInPage() {
  // Check if we are actually in a detail view (back button should exist)
  const backBtn = document.querySelector('button[aria-label*="Back"], button[aria-label*="Kembali"], [jsaction*="back"]');
  if (backBtn) { 
    backBtn.click(); 
    return true; 
  }
  return false;
}

function scrapeDetailInPage() {
  const d = { 
    name: '', 
    address: '', 
    phone: '', 
    rating: '', 
    reviewCount: '', 
    website: '', 
    category: '', 
    url: window.location.href 
  };

  try {
      // 1. Business Name
      const titleSelectors = ['h1.DUwDvf', 'h1.fontHeadlineLarge', 'h1'];
      for (const sel of titleSelectors) {
          const el = document.querySelector(sel);
          if (el && el.textContent.trim()) {
              const text = el.textContent.trim();
              if (!text.toLowerCase().includes('hasil') && !text.toLowerCase().includes('results')) {
                  d.name = text;
                  break;
              }
          }
      }

      // 2. Rating & Reviews
      const ratingContainer = document.querySelector('div.F7nice');
      if (ratingContainer) {
          const rEl = ratingContainer.querySelector('span[aria-hidden="true"]');
          if (rEl) d.rating = rEl.textContent.trim().replace(',', '.');
          
          const revEl = ratingContainer.querySelector('span[aria-label*="review"], span[aria-label*="ulasan"]');
          if (revEl) {
              const m = revEl.getAttribute('aria-label').match(/([\d.,]+)/);
              if (m) d.reviewCount = m[1].replace(/[.,]/g, '');
          }
      }

      // 3. Category
      const catSelectors = ['button[jsaction*="category"]', '.DkEaL', '.fontBodyMedium'];
      for (const sel of catSelectors) {
          const el = document.querySelector(sel);
          if (el && el.textContent.trim() && el.textContent.length < 50) {
              d.category = el.textContent.trim();
              break;
          }
      }

      // 4. Address, Phone, Website (Data Item IDs are usually most stable)
      const infoItems = document.querySelectorAll('[data-item-id]');
      infoItems.forEach(item => {
          const id = item.getAttribute('data-item-id');
          const label = item.getAttribute('aria-label') || '';
          const text = item.textContent.trim();

          if (id && id.includes('address')) {
              d.address = label.replace(/^(Alamat|Address):\s*/i, '') || text;
          } else if (id && id.includes('phone')) {
              d.phone = label.replace(/^(Telepon|Phone):\s*/i, '') || text;
          } else if (id && id.includes('authority')) {
              const a = item.querySelector('a') || item;
              d.website = a.href || text;
              if (d.website && d.website.startsWith('/')) {
                  // If it's a relative link, it's probably not the website
                  d.website = '';
              }
          }
      });

      // Special check for website if not found
      if (!d.website) {
          const webEl = document.querySelector('a[aria-label*="Website"], a[aria-label*="Situs"]');
          if (webEl) d.website = webEl.href;
      }

  } catch (e) {
      console.error("Extraction error:", e);
  }

  return d.name ? d : null;
}

