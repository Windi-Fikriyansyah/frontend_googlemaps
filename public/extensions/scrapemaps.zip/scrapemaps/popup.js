/**
 * ScrapeMaps - Popup Script (UI Only)
 * Communicates with background service worker to manage long-running scrapes
 */

// ===== DOM Elements =====
const btnScrape = document.getElementById('btnScrape');
const btnStop = document.getElementById('btnStop');
const btnExportCSV = document.getElementById('btnExportCSV');
const btnExportJSON = document.getElementById('btnExportJSON');
const btnExportExcel = document.getElementById('btnExportExcel');
const btnCopy = document.getElementById('btnCopy');
const btnClear = document.getElementById('btnClear');
const inputLimit = document.getElementById('inputLimit');
const connectionStatus = document.getElementById('connectionStatus');
const alertBox = document.getElementById('alertBox');
const alertText = document.getElementById('alertText');
const statsBar = document.getElementById('statsBar');
const statTotal = document.getElementById('statTotal');
const statWithPhone = document.getElementById('statWithPhone');
const statWithWebsite = document.getElementById('statWithWebsite');
const progressSection = document.getElementById('progressSection');
const progressLabel = document.getElementById('progressLabel');
const progressCount = document.getElementById('progressCount');
const progressBar = document.getElementById('progressBar');
const resultsSection = document.getElementById('resultsSection');
const resultsBody = document.getElementById('resultsBody');
const emptyState = document.getElementById('emptyState');

// ===== State =====
let scrapedData = [];
let currentTabId = null;

// ===== Initialize =====
document.addEventListener('DOMContentLoaded', async () => {
  // Initial load
  const stored = await chrome.storage.local.get(['scrapedData', 'scrapeLimit', 'scrapingState']);
  if (stored.scrapedData && stored.scrapedData.length > 0) {
    scrapedData = stored.scrapedData;
    renderResults();
    updateStats();
  }
  if (stored.scrapeLimit) inputLimit.value = stored.scrapeLimit;

  // Poll for background status changes
  updateUIFromBackground(stored.scrapingState);
  setInterval(async () => {
    const s = await chrome.storage.local.get(['scrapingState', 'scrapedData']);
    if (s.scrapedData) {
        scrapedData = s.scrapedData;
        renderResults();
        updateStats();
    }
    updateUIFromBackground(s.scrapingState);
  }, 1000);

  await checkConnection();
});

function updateUIFromBackground(state) {
  if (state && state.active) {
    btnScrape.classList.add('scraping');
    btnScrape.querySelector('span').textContent = 'Running...';
    btnScrape.disabled = true;
    btnStop.disabled = false;
    inputLimit.disabled = true;
    progressSection.style.display = 'block';
    
    // Update progress bar
    const total = state.limit;
    const cur = state.current;
    const pct = 20 + Math.round((cur / total) * 80);
    progressLabel.textContent = `Scraping: ${cur}/${total}`;
    progressCount.textContent = cur.toString();
    progressBar.style.width = `${pct}%`;
  } else {
    btnScrape.classList.remove('scraping');
    btnScrape.querySelector('span').textContent = 'Mulai Scrape';
    btnScrape.disabled = false;
    btnStop.disabled = true;
    inputLimit.disabled = false;
    progressSection.style.display = 'none';
  }
}

inputLimit.addEventListener('change', () => {
  let val = Math.max(1, Math.min(500, parseInt(inputLimit.value) || 20));
  inputLimit.value = val;
  chrome.storage.local.set({ scrapeLimit: val });
});

async function checkConnection() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && (tab.url?.includes('google.com/maps') || tab.url?.includes('maps.google.com'))) {
    currentTabId = tab.id;
    connectionStatus.classList.add('connected');
    connectionStatus.querySelector('.status-text').textContent = 'Google Maps';
  } else {
    connectionStatus.classList.remove('connected');
    connectionStatus.querySelector('.status-text').textContent = 'Bukan Maps';
    btnScrape.disabled = true;
  }
}

function showAlert(message, type = 'info') {
  alertBox.className = `alert alert-${type}`;
  alertText.textContent = message;
  alertBox.style.display = 'flex';
  setTimeout(() => { alertBox.style.display = 'none'; }, 5000);
}

function showToast(message, type = 'success') {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="${type === 'success' ? '#10b981' : '#ef4444'}" stroke-width="1.5">
      ${type === 'success' ? '<path d="M3 7l3 3 5-5"/><circle cx="7" cy="7" r="6"/>' : '<circle cx="7" cy="7" r="6"/><path d="M5 5l4 4M9 5l-4 4"/>'}
    </svg>
    <span>${message}</span>
  `;
  document.body.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); }, 2500);
}

// ===== CALL BACKGROUND =====
btnScrape.addEventListener('click', () => {
  if (!currentTabId) return;
  const limit = parseInt(inputLimit.value) || 20;
  chrome.runtime.sendMessage({ action: "startScrape", tabId: currentTabId, limit: limit }, (res) => {
    showToast("Scraping dimulai di background...");
  });
});

btnStop.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: "stopScrape" }, (res) => {
    showToast("Menghentikan scraping...", "error");
  });
});

// ===== Render Results (Same as before) =====
function renderResults() {
  if (scrapedData.length === 0) {
    resultsSection.style.display = 'none';
    emptyState.style.display = 'flex';
    statsBar.style.display = 'none';
    return;
  }
  emptyState.style.display = 'none';
  resultsSection.style.display = 'block';
  statsBar.style.display = 'flex';
  resultsBody.innerHTML = '';
  scrapedData.forEach((item, index) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${index + 1}</td>
      <td title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</td>
      <td title="${escapeHtml(item.address || '')}">${escapeHtml(item.address || '-')}</td>
      <td>${item.phone ? `<a href="tel:${item.phone}">${item.phone}</a>` : '-'}</td>
      <td>${item.rating ? `<span class="rating-cell">★ ${item.rating}</span>` : '-'}</td>
      <td>${item.reviewCount || '-'}</td>
      <td>${item.website ? `<a href="${item.website}" target="_blank">Link</a>` : '-'}</td>
    `;
    resultsBody.appendChild(tr);
  });
}

function updateStats() {
  statTotal.textContent = scrapedData.length;
  statWithPhone.textContent = scrapedData.filter(d => d.phone).length;
  statWithWebsite.textContent = scrapedData.filter(d => d.website).length;
}

btnExportCSV.addEventListener('click', () => {
  if (scrapedData.length === 0) return;
  const headers = ['No', 'Nama Bisnis', 'Alamat', 'Telepon', 'Rating', 'Review', 'Website', 'Kategori'];
  const rows = scrapedData.map((item, i) => [i + 1, `"${(item.name || '').replace(/"/g, '""')}"`, `"${(item.address || '').replace(/"/g, '""')}"`, `"${item.phone || ''}"`, item.rating || '', item.reviewCount || '', `"${item.website || ''}"`, `"${(item.category || '').replace(/"/g, '""')}"`]);
  const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `scrapemaps.csv`;
  a.click();
});

btnExportJSON.addEventListener('click', () => {
    if (scrapedData.length === 0) return;
    const blob = new Blob([JSON.stringify(scrapedData, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `scrapemaps.json`;
    a.click();
});

// ===== EXPORT EXCEL (.xls SpreadsheetML) =====
btnExportExcel.addEventListener('click', () => {
    if (scrapedData.length === 0) return;
    
    let xml = `<?xml version="1.0"?>
    <?mso-application progid="Excel.Sheet"?>
    <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
     xmlns:o="urn:schemas-microsoft-com:office:office"
     xmlns:x="urn:schemas-microsoft-com:office:excel"
     xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
     xmlns:html="http://www.w3.org/TR/REC-html40">
     <Styles>
      <Style ss:ID="s62">
       <Font ss:Bold="1"/>
       <Interior ss:Color="#6366f1" ss:Pattern="Solid"/>
       <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
       <Font ss:Color="#FFFFFF"/>
      </Style>
     </Styles>
     <Worksheet ss:Name="ScrapeMaps Results">
      <Table>
       <Column ss:Width="30"/>
       <Column ss:Width="150"/>
       <Column ss:Width="250"/>
       <Column ss:Width="100"/>
       <Column ss:Width="50"/>
       <Column ss:Width="50"/>
       <Column ss:Width="100"/>
       <Column ss:Width="100"/>
       <Row ss:StyleID="s62">
        <Cell><Data ss:Type="String">No</Data></Cell>
        <Cell><Data ss:Type="String">Nama Bisnis</Data></Cell>
        <Cell><Data ss:Type="String">Alamat</Data></Cell>
        <Cell><Data ss:Type="String">Telepon</Data></Cell>
        <Cell><Data ss:Type="String">Rating</Data></Cell>
        <Cell><Data ss:Type="String">Review</Data></Cell>
        <Cell><Data ss:Type="String">Website</Data></Cell>
        <Cell><Data ss:Type="String">Kategori</Data></Cell>
       </Row>`;

    scrapedData.forEach((d, i) => {
        xml += `<Row>
            <Cell><Data ss:Type="Number">${i + 1}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.name || '-')}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.address || '-')}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.phone || '-')}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.rating || '-')}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.reviewCount || '-')}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.website || '-')}</Data></Cell>
            <Cell><Data ss:Type="String">${escapeXml(d.category || '-')}</Data></Cell>
        </Row>`;
    });

    xml += `</Table></Worksheet></Workbook>`;

    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `scrapemaps_${formatDate()}.xls`;
    a.click();
    showToast("Excel berhasil didownload!");
});

function escapeXml(unsafe) {
    if (!unsafe) return "";
    return unsafe.replace(/[<>&'"]/g, function (c) {
        switch (c) {
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '&': return '&amp;';
            case '\'': return '&apos;';
            case '"': return '&quot;';
        }
    });
}

function formatDate() {
    const now = new Date();
    return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
}

btnCopy.addEventListener('click', async () => {
  const text = scrapedData.map((item, i) => `${i + 1}. ${item.name} | ${item.address || '-'} | ${item.phone || '-'}`).join('\n');
  await navigator.clipboard.writeText(text);
  showToast('Data berhasil dicopy!');
});

btnClear.addEventListener('click', async () => {
  if (confirm('Hapus semua data?')) {
    scrapedData = [];
    await chrome.storage.local.set({ scrapedData: [] });
    renderResults();
    updateStats();
  }
});

function escapeHtml(t) { const d = document.createElement('div'); d.textContent = t; return d.innerHTML; }
